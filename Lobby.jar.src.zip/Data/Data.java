/*   */ package Data;
/*   */ 
/*   */ import org.bukkit.event.Listener;
/*   */ 
/*   */ public class Data
/*   */   implements Listener {
/* 7 */   public static String CHAT_PREFIX = "§8┃ §aLobby §8● ";
/* 8 */   public static String CHAT_NOPERM = "§7Unbekannter Befehl";
/*   */ }


/* Location:              C:\Users\maxim\Desktop\Lobby.jar!\Data\Data.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */