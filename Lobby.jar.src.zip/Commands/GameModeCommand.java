/*    */ package Commands;
/*    */ 
/*    */ import Data.Data;
/*    */ import org.bukkit.GameMode;
/*    */ import org.bukkit.command.Command;
/*    */ import org.bukkit.command.CommandExecutor;
/*    */ import org.bukkit.command.CommandSender;
/*    */ import org.bukkit.entity.Player;
/*    */ 
/*    */ 
/*    */ public class GameModeCommand
/*    */   implements CommandExecutor
/*    */ {
/*    */   public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
/* 15 */     Player p = (Player)sender;
/*    */     
/* 17 */     if (p.hasPermission("lobby.gamemode")) {
/* 18 */       if (cmd.getName().equalsIgnoreCase("gamemode")) {
/* 19 */         if (args.length == 1) {
/* 20 */           if (args[0].equalsIgnoreCase("0") && 
/* 21 */             p.getGameMode() != GameMode.SURVIVAL) {
/* 22 */             p.setGameMode(GameMode.SURVIVAL);
/* 23 */             p.sendMessage(String.valueOf(String.valueOf(Data.CHAT_PREFIX)) + "Â§7Dein Spielmodus ist nunÂ§8: Â§eÃœberleben");
/*    */           } 
/*    */           
/* 26 */           if (args[0].equalsIgnoreCase("1") && 
/* 27 */             p.getGameMode() != GameMode.CREATIVE) {
/* 28 */             p.setGameMode(GameMode.CREATIVE);
/* 29 */             p.sendMessage(String.valueOf(String.valueOf(Data.CHAT_PREFIX)) + "Â§7Dein Spielmodus ist nunÂ§8: Â§eKreativ");
/*    */           } 
/*    */           
/* 32 */           if (args[0].equalsIgnoreCase("2") && 
/* 33 */             p.getGameMode() != GameMode.ADVENTURE) {
/* 34 */             p.setGameMode(GameMode.ADVENTURE);
/* 35 */             p.sendMessage(String.valueOf(String.valueOf(Data.CHAT_PREFIX)) + "Â§7Dein Spielmodus ist nunÂ§8: Â§eAbenteuer");
/*    */           } 
/*    */           
/* 38 */           if (args[0].equalsIgnoreCase("3") && 
/* 39 */             p.getGameMode() != GameMode.SPECTATOR) {
/* 40 */             p.setGameMode(GameMode.SPECTATOR);
/* 41 */             p.sendMessage(String.valueOf(String.valueOf(Data.CHAT_PREFIX)) + "Â§7Dein Spielmodus ist nunÂ§8: Â§eZuschauer");
/*    */           } 
/*    */         } else {
/*    */           
/* 45 */           p.sendMessage(String.valueOf(String.valueOf(Data.CHAT_PREFIX)) + "Â§7BenutzeÂ§8: Â§e/gamemode <0Â§8â”ƒÂ§e1Â§8â”ƒÂ§e2Â§8â”ƒÂ§e3>");
/*    */         } 
/*    */       }
/*    */     } else {
/* 49 */       p.sendMessage(Data.CHAT_NOPERM);
/*    */     } 
/* 51 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Users\maxim\Desktop\Lobby.jar!\Commands\GameModeCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */