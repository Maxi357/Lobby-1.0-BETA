/*    */ package Commands;
/*    */ 
/*    */ import Data.Data;
/*    */ import Main.Main;
/*    */ import org.bukkit.command.Command;
/*    */ import org.bukkit.command.CommandExecutor;
/*    */ import org.bukkit.command.CommandSender;
/*    */ import org.bukkit.entity.Player;
/*    */ 
/*    */ public class SetSpawnCommand
/*    */   implements CommandExecutor
/*    */ {
/*    */   private Main pl;
/*    */   
/*    */   public SetSpawnCommand(Main pl) {
/* 16 */     this.pl = pl;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
/* 21 */     Player p = (Player)sender;
/*    */     
/* 23 */     if (!(sender instanceof Player)) {
/* 24 */       sender.sendMessage(String.valueOf(String.valueOf(Data.CHAT_PREFIX)) + "Â§cDu bist kein SpielerÂ§7!");
/*    */     }
/* 26 */     if (p.hasPermission("lobby.setwarp")) {
/* 27 */       if (cmd.getName().equalsIgnoreCase("setwarp")) {
/* 28 */         if (args.length == 1) {
/* 29 */           if (args[0].equalsIgnoreCase("spawn")) {
/* 30 */             this.pl.getConfig().set("spawn.world", p.getLocation().getWorld().getName());
/* 31 */             this.pl.getConfig().set("spawn.x", Double.valueOf(p.getLocation().getX()));
/* 32 */             this.pl.getConfig().set("spawn.y", Double.valueOf(p.getLocation().getY()));
/* 33 */             this.pl.getConfig().set("spawn.z", Double.valueOf(p.getLocation().getZ()));
/* 34 */             this.pl.getConfig().set("spawn.yaw", Float.valueOf(p.getLocation().getYaw()));
/* 35 */             this.pl.getConfig().set("spawn.pitch", Float.valueOf(p.getLocation().getPitch()));
/* 36 */             p.sendMessage(String.valueOf(String.valueOf(Data.CHAT_PREFIX)) + "Â§7Der Warp Â§eSpawn Â§7wurde gesetzt");
/* 37 */             this.pl.saveConfig();
/*    */           } 
/* 39 */           if (args[0].equalsIgnoreCase("skypvp")) {
/* 40 */             this.pl.getConfig().set("spawn.skypvp.world", p.getLocation().getWorld().getName());
/* 41 */             this.pl.getConfig().set("spawn.skypvp.x", Double.valueOf(p.getLocation().getX()));
/* 42 */             this.pl.getConfig().set("spawn.skypvp.y", Double.valueOf(p.getLocation().getY()));
/* 43 */             this.pl.getConfig().set("spawn.skypvp.z", Double.valueOf(p.getLocation().getZ()));
/* 44 */             this.pl.getConfig().set("spawn.skypvp.yaw", Float.valueOf(p.getLocation().getYaw()));
/* 45 */             this.pl.getConfig().set("spawn.skypvp.pitch", Float.valueOf(p.getLocation().getPitch()));
/* 46 */             p.sendMessage(String.valueOf(String.valueOf(Data.CHAT_PREFIX)) + "Â§7Der Warp Â§eSkyPvP Â§7wurde gesetzt");
/* 47 */             this.pl.saveConfig();
/*    */           } 
/* 49 */           if (args[0].equalsIgnoreCase("knockout")) {
/* 50 */             this.pl.getConfig().set("spawn.knockout.world", p.getLocation().getWorld().getName());
/* 51 */             this.pl.getConfig().set("spawn.knockout.x", Double.valueOf(p.getLocation().getX()));
/* 52 */             this.pl.getConfig().set("spawn.knockout.y", Double.valueOf(p.getLocation().getY()));
/* 53 */             this.pl.getConfig().set("spawn.knockout.z", Double.valueOf(p.getLocation().getZ()));
/* 54 */             this.pl.getConfig().set("spawn.knockout.yaw", Float.valueOf(p.getLocation().getYaw()));
/* 55 */             this.pl.getConfig().set("spawn.knockout.pitch", Float.valueOf(p.getLocation().getPitch()));
/* 56 */             p.sendMessage(String.valueOf(String.valueOf(Data.CHAT_PREFIX)) + "Â§7Der Warp Â§eKnockOut Â§7wurde gesetzt");
/* 57 */             this.pl.saveConfig();
/*    */           } 
/* 59 */           if (args[0].equalsIgnoreCase("comingsoon")) {
/* 60 */             this.pl.getConfig().set("spawn.comingsoon.world", p.getLocation().getWorld().getName());
/* 61 */             this.pl.getConfig().set("spawn.comingsoon.x", Double.valueOf(p.getLocation().getX()));
/* 62 */             this.pl.getConfig().set("spawn.comingsoon.y", Double.valueOf(p.getLocation().getY()));
/* 63 */             this.pl.getConfig().set("spawn.comingsoon.z", Double.valueOf(p.getLocation().getZ()));
/* 64 */             this.pl.getConfig().set("spawn.comingsoon.yaw", Float.valueOf(p.getLocation().getYaw()));
/* 65 */             this.pl.getConfig().set("spawn.comingsoon.pitch", Float.valueOf(p.getLocation().getPitch()));
/* 66 */             p.sendMessage(String.valueOf(String.valueOf(Data.CHAT_PREFIX)) + "Â§7Der Warp Â§eComing-Soon Â§7wurde gesetzt");
/* 67 */             this.pl.saveConfig();
/*    */           } 
/* 69 */           if (args[0].equalsIgnoreCase("community")) {
/* 70 */             this.pl.getConfig().set("spawn.community.world", p.getLocation().getWorld().getName());
/* 71 */             this.pl.getConfig().set("spawn.community.x", Double.valueOf(p.getLocation().getX()));
/* 72 */             this.pl.getConfig().set("spawn.community.y", Double.valueOf(p.getLocation().getY()));
/* 73 */             this.pl.getConfig().set("spawn.community.z", Double.valueOf(p.getLocation().getZ()));
/* 74 */             this.pl.getConfig().set("spawn.community.yaw", Float.valueOf(p.getLocation().getYaw()));
/* 75 */             this.pl.getConfig().set("spawn.community.pitch", Float.valueOf(p.getLocation().getPitch()));
/* 76 */             p.sendMessage(String.valueOf(String.valueOf(Data.CHAT_PREFIX)) + "Â§7Der Warp Â§eCommunity Â§7wurde gesetzt");
/* 77 */             this.pl.saveConfig();
/*    */           } 
/*    */         } else {
/*    */           
/* 81 */           p.sendMessage(String.valueOf(String.valueOf(Data.CHAT_PREFIX)) + "Â§7BenutzeÂ§8: Â§e/Setwarp <Warp>");
/*    */         } 
/*    */       }
/*    */     } else {
/* 85 */       p.sendMessage(Data.CHAT_NOPERM);
/*    */     } 
/* 87 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Users\maxim\Desktop\Lobby.jar!\Commands\SetSpawnCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */