/*    */ package Commands;
/*    */ 
/*    */ import Data.Data;
/*    */ import Main.Main;
/*    */ import org.bukkit.command.Command;
/*    */ import org.bukkit.command.CommandExecutor;
/*    */ import org.bukkit.command.CommandSender;
/*    */ import org.bukkit.entity.Player;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BuildCommand
/*    */   implements CommandExecutor
/*    */ {
/*    */   private Main pl;
/*    */   
/*    */   public BuildCommand(Main pl) {
/* 18 */     this.pl = pl;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
/* 23 */     Player p = (Player)sender;
/*    */     
/* 25 */     if (!(sender instanceof Player)) {
/* 26 */       sender.sendMessage(String.valueOf(String.valueOf(Data.CHAT_PREFIX)) + "Â§cDu bist kein SpielerÂ§7!");
/*    */     }
/* 28 */     if (p.hasPermission("lobby.build") && 
/* 29 */       cmd.getName().equalsIgnoreCase("build")) {
/* 30 */       if (args.length == 0) {
/* 31 */         if (this.pl.buildmode.contains(p)) {
/* 32 */           this.pl.buildmode.remove(p);
/* 33 */           p.sendMessage(String.valueOf(String.valueOf(Data.CHAT_PREFIX)) + "Â§7Dein BauModus wurde Â§cDeaktiviert");
/*    */         } else {
/* 35 */           this.pl.buildmode.add(p);
/* 36 */           p.sendMessage(String.valueOf(String.valueOf(Data.CHAT_PREFIX)) + "Â§7Dein BauModus wurde Â§aAktiviert");
/*    */         } 
/*    */       } else {
/* 39 */         p.sendMessage(Data.CHAT_NOPERM);
/*    */       } 
/*    */     }
/*    */     
/* 43 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Users\maxim\Desktop\Lobby.jar!\Commands\BuildCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */