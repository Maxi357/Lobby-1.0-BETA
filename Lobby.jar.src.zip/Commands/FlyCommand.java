/*    */ package Commands;
/*    */ 
/*    */ import Data.Data;
/*    */ import Main.Main;
/*    */ import org.bukkit.command.Command;
/*    */ import org.bukkit.command.CommandExecutor;
/*    */ import org.bukkit.command.CommandSender;
/*    */ import org.bukkit.entity.Player;
/*    */ 
/*    */ public class FlyCommand
/*    */   implements CommandExecutor
/*    */ {
/*    */   private Main pl;
/*    */   
/*    */   public FlyCommand(Main pl) {
/* 16 */     this.pl = pl;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
/* 21 */     Player p = (Player)sender;
/*    */     
/* 23 */     if (!(sender instanceof Player)) {
/* 24 */       sender.sendMessage(String.valueOf(String.valueOf(Data.CHAT_PREFIX)) + "Â§cDu bist kein SpielerÂ§7!");
/*    */     }
/* 26 */     if (p.hasPermission("lobby.fly") && 
/* 27 */       cmd.getName().equalsIgnoreCase("fly") && 
/* 28 */       args.length == 0) {
/* 29 */       if (this.pl.flymode.contains(p)) {
/* 30 */         this.pl.flymode.remove(p);
/* 31 */         p.setAllowFlight(false);
/* 32 */         p.setFlying(false);
/* 33 */         p.sendMessage(String.valueOf(String.valueOf(Data.CHAT_PREFIX)) + "Â§7Dein Flugmodus wurde Â§cDeaktiviert");
/*    */       } else {
/* 35 */         this.pl.flymode.add(p);
/* 36 */         p.setAllowFlight(true);
/* 37 */         p.setFlying(true);
/* 38 */         p.sendMessage(String.valueOf(String.valueOf(Data.CHAT_PREFIX)) + "Â§7Dein Flugmodus wurde Â§aAktiviert");
/*    */       } 
/*    */     }
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 45 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Users\maxim\Desktop\Lobby.jar!\Commands\FlyCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */