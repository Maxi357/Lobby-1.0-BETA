/*    */ package Listener;
/*    */ 
/*    */ import org.bukkit.ChatColor;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.EventHandler;
/*    */ import org.bukkit.event.Listener;
/*    */ import org.bukkit.event.player.AsyncPlayerChatEvent;
/*    */ import ru.tehkode.permissions.bukkit.PermissionsEx;
/*    */ 
/*    */ public class ChatListener
/*    */   implements Listener
/*    */ {
/*    */   @EventHandler
/*    */   public void ChatEvent(AsyncPlayerChatEvent e) {
/* 15 */     Player p = e.getPlayer();
/* 16 */     if (p.hasPermission("lobby.premium")) {
/* 17 */       e.setMessage(ChatColor.translateAlternateColorCodes('&', e.getMessage()));
/*    */     }
/* 19 */     if (PermissionsEx.getUser(p).inGroup("Owner")) {
/* 20 */       e.setCancelled(false);
/* 21 */       e.setFormat("§8● §4Owner §8┃ §4" + p.getName() + " §8» §7" + e.getMessage());
/*    */     }
/* 23 */     else if (PermissionsEx.getUser(p).inGroup("Admin")) {
/* 24 */       e.setCancelled(false);
/* 25 */       e.setFormat("§8● §4Admin §8┃ §4" + p.getName() + " §8» §7" + e.getMessage());
/*    */     }
/* 27 */     else if (PermissionsEx.getUser(p).inGroup("SrDeveloper")) {
/* 28 */       e.setCancelled(false);
/* 29 */       e.setFormat("§8● §bSrDeveloper §8┃ §b" + p.getName() + " §8» §7" + e.getMessage());
/*    */     }
/* 31 */     else if (PermissionsEx.getUser(p).inGroup("SrBuilder")) {
/* 32 */       e.setCancelled(false);
/* 33 */       e.setFormat("§8● §2SrBuilder §8┃ §2" + p.getName() + " §8» §7" + e.getMessage());
/*    */     }
/* 35 */     else if (PermissionsEx.getUser(p).inGroup("SrModerator")) {
/* 36 */       e.setCancelled(false);
/* 37 */       e.setFormat("§8● §9SrModerator §8┃ §9" + p.getName() + " §8» §7" + e.getMessage());
/*    */     }
/* 39 */     else if (PermissionsEx.getUser(p).inGroup("Developer")) {
/* 40 */       e.setCancelled(false);
/* 41 */       e.setFormat("§8● §bDeveloper §8┃ §b" + p.getName() + " §8» §7" + e.getMessage());
/*    */     }
/* 43 */     else if (PermissionsEx.getUser(p).inGroup("Moderator")) {
/* 44 */       e.setCancelled(false);
/* 45 */       e.setFormat("§8● §9Moderator §8┃ §9" + p.getName() + "§8 » §7" + e.getMessage());
/*    */     }
/* 47 */     else if (PermissionsEx.getUser(p).inGroup("Builder")) {
/* 48 */       e.setCancelled(false);
/* 49 */       e.setFormat("§8● §2Builder §8┃ §2" + p.getName() + " §8» §7" + e.getMessage());
/*    */     }
/* 51 */     else if (PermissionsEx.getUser(p).inGroup("Supporter")) {
/* 52 */       e.setCancelled(false);
/* 53 */       e.setFormat("§8● §3Supporter §8┃ §3" + p.getName() + " §8» §7" + e.getMessage());
/*    */     }
/* 55 */     else if (PermissionsEx.getUser(p).inGroup("YouTuber")) {
/* 56 */       e.setCancelled(false);
/* 57 */       e.setFormat("§8● §5YouTuber §8┃ §5" + p.getName() + " §8» §7" + e.getMessage());
/*    */     }
/* 59 */     else if (PermissionsEx.getUser(p).inGroup("Premium+")) {
/* 60 */       e.setCancelled(false);
/* 61 */       e.setFormat("§8● §ePremium+ §8┃ §e" + p.getName() + " §8» §7" + e.getMessage());
/*    */     }
/* 63 */     else if (PermissionsEx.getUser(p).inGroup("Premium")) {
/* 64 */       e.setCancelled(false);
/* 65 */       e.setFormat("§8● §6Premium §8┃ §6" + p.getName() + " §8» §7" + e.getMessage());
/*    */     } else {
/* 67 */       e.setCancelled(false);
/* 68 */       e.setFormat("§8● §7Spieler §8┃ §7" + p.getName() + " §8» §7" + e.getMessage());
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\maxim\Desktop\Lobby.jar!\Listener\ChatListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */