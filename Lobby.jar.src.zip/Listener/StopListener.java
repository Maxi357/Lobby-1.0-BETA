/*    */ package Listener;
/*    */ 
/*    */ import Data.Data;
/*    */ import org.bukkit.Bukkit;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.EventHandler;
/*    */ import org.bukkit.event.Listener;
/*    */ import org.bukkit.event.player.PlayerCommandPreprocessEvent;
/*    */ 
/*    */ public class StopListener
/*    */   implements Listener
/*    */ {
/*    */   @EventHandler
/*    */   public void StopEvent(PlayerCommandPreprocessEvent e) {
/* 15 */     Player p = e.getPlayer();
/* 16 */     if (p.hasPermission("lobby.admin") && (e.getMessage().equalsIgnoreCase("/stop") || e.getMessage().equalsIgnoreCase("/restart")))
/* 17 */       for (Player all : Bukkit.getOnlinePlayers()) {
/* 18 */         all.sendMessage(String.valueOf(String.valueOf(Data.CHAT_PREFIX)) + "Â§7Der Server wird gestoppt");
/* 19 */         Bukkit.shutdown();
/*    */       }  
/*    */   }
/*    */ }


/* Location:              C:\Users\maxim\Desktop\Lobby.jar!\Listener\StopListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */