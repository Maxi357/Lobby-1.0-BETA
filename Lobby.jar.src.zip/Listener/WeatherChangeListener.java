/*    */ package Listener;
/*    */ 
/*    */ import org.bukkit.event.EventHandler;
/*    */ import org.bukkit.event.Listener;
/*    */ import org.bukkit.event.weather.WeatherChangeEvent;
/*    */ 
/*    */ public class WeatherChangeListener
/*    */   implements Listener {
/*    */   @EventHandler
/*    */   public void WeatherChangeEvent(WeatherChangeEvent e) {
/* 11 */     e.setCancelled(true);
/*    */   }
/*    */ }


/* Location:              C:\Users\maxim\Desktop\Lobby.jar!\Listener\WeatherChangeListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */