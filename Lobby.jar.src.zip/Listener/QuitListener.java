/*    */ package Listener;
/*    */ 
/*    */ import org.bukkit.event.EventHandler;
/*    */ import org.bukkit.event.Listener;
/*    */ import org.bukkit.event.player.PlayerQuitEvent;
/*    */ 
/*    */ public class QuitListener
/*    */   implements Listener {
/*    */   @EventHandler
/*    */   public void QuitEvent(PlayerQuitEvent e) {
/* 11 */     e.setQuitMessage(null);
/*    */   }
/*    */ }


/* Location:              C:\Users\maxim\Desktop\Lobby.jar!\Listener\QuitListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */