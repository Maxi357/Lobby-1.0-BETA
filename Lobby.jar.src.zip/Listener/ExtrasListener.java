/*    */ package Listener;
/*    */ 
/*    */ import Methods.Settings;
/*    */ import org.bukkit.Bukkit;
/*    */ import org.bukkit.Material;
/*    */ import org.bukkit.Sound;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.EventHandler;
/*    */ import org.bukkit.event.Listener;
/*    */ import org.bukkit.event.block.Action;
/*    */ import org.bukkit.event.player.PlayerInteractEvent;
/*    */ import org.bukkit.inventory.Inventory;
/*    */ 
/*    */ public class ExtrasListener
/*    */   implements Listener
/*    */ {
/* 17 */   public static Inventory inv = Bukkit.createInventory(null, 27, "Â§8â—� Â§7Extras Â§8â—�");
/*    */   
/*    */   @EventHandler
/*    */   public void onInteract(PlayerInteractEvent e) {
/* 21 */     Player p = e.getPlayer();
/*    */     
/* 23 */     if ((e.getAction().equals(Action.RIGHT_CLICK_BLOCK) || e.getAction().equals(Action.RIGHT_CLICK_AIR)) && 
/* 24 */       p.getItemInHand().getType() == Material.ENDER_CHEST) {
/* 25 */       inv.setItem(0, Settings.CreateItemwithID(Material.STAINED_GLASS_PANE, 7, 1, " "));
/* 26 */       inv.setItem(1, Settings.CreateItemwithID(Material.STAINED_GLASS_PANE, 7, 1, " "));
/* 27 */       inv.setItem(2, Settings.CreateItemwithID(Material.STAINED_GLASS_PANE, 7, 1, " "));
/* 28 */       inv.setItem(3, Settings.CreateItemwithID(Material.STAINED_GLASS_PANE, 7, 1, " "));
/* 29 */       inv.setItem(4, Settings.CreateItemwithID(Material.STAINED_GLASS_PANE, 7, 1, " "));
/* 30 */       inv.setItem(5, Settings.CreateItemwithID(Material.STAINED_GLASS_PANE, 7, 1, " "));
/* 31 */       inv.setItem(6, Settings.CreateItemwithID(Material.STAINED_GLASS_PANE, 7, 1, " "));
/* 32 */       inv.setItem(7, Settings.CreateItemwithID(Material.STAINED_GLASS_PANE, 7, 1, " "));
/* 33 */       inv.setItem(8, Settings.CreateItemwithID(Material.STAINED_GLASS_PANE, 7, 1, " "));
/* 34 */       inv.setItem(9, Settings.CreateItemwithID(Material.STAINED_GLASS_PANE, 7, 1, " "));
/* 35 */       inv.setItem(10, Settings.CreateItemwithID(Material.STAINED_GLASS_PANE, 7, 1, " "));
/* 36 */       inv.setItem(11, Settings.CreateItemwithID(Material.PUMPKIN, 0, 1, "Â§6HÃ¼te Â§7- Â§7Â§lFree"));
/* 37 */       inv.setItem(12, Settings.CreateItemwithID(Material.STAINED_GLASS_PANE, 7, 1, " "));
/* 38 */       inv.setItem(13, Settings.CreateItemwithID(Material.STAINED_GLASS_PANE, 7, 1, " "));
/* 39 */       inv.setItem(14, Settings.CreateItemwithID(Material.STAINED_GLASS_PANE, 7, 1, " "));
/* 40 */       inv.setItem(15, Settings.CreateItemwithID(Material.STAINED_CLAY, 14, 1, "Â§6Ballons Â§7- Â§6Â§lPremium"));
/* 41 */       inv.setItem(16, Settings.CreateItemwithID(Material.STAINED_GLASS_PANE, 7, 1, " "));
/* 42 */       inv.setItem(17, Settings.CreateItemwithID(Material.STAINED_GLASS_PANE, 7, 1, " "));
/* 43 */       inv.setItem(18, Settings.CreateItemwithID(Material.STAINED_GLASS_PANE, 7, 1, " "));
/* 44 */       inv.setItem(19, Settings.CreateItemwithID(Material.STAINED_GLASS_PANE, 7, 1, " "));
/* 45 */       inv.setItem(20, Settings.CreateItemwithID(Material.STAINED_GLASS_PANE, 7, 1, " "));
/* 46 */       inv.setItem(21, Settings.CreateItemwithID(Material.STAINED_GLASS_PANE, 7, 1, " "));
/* 47 */       inv.setItem(22, Settings.CreateItemwithID(Material.STAINED_GLASS_PANE, 7, 1, " "));
/* 48 */       inv.setItem(23, Settings.CreateItemwithID(Material.STAINED_GLASS_PANE, 7, 1, " "));
/* 49 */       inv.setItem(24, Settings.CreateItemwithID(Material.STAINED_GLASS_PANE, 7, 1, " "));
/* 50 */       inv.setItem(25, Settings.CreateItemwithID(Material.STAINED_GLASS_PANE, 7, 1, " "));
/* 51 */       p.openInventory(inv);
/* 52 */       p.playSound(p.getLocation(), Sound.CLICK, 1.0F, 1.0F);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\maxim\Desktop\Lobby.jar!\Listener\ExtrasListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */