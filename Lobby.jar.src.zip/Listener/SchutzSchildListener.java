/*     */ package Listener;
/*     */ 
/*     */ import Data.Data;
/*     */ import Main.Main;
/*     */ import java.util.HashMap;
/*     */ import org.bukkit.Effect;
/*     */ import org.bukkit.Material;
/*     */ import org.bukkit.Sound;
/*     */ import org.bukkit.entity.Entity;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.event.EventHandler;
/*     */ import org.bukkit.event.Listener;
/*     */ import org.bukkit.event.block.Action;
/*     */ import org.bukkit.event.player.PlayerInteractEvent;
/*     */ import org.bukkit.event.player.PlayerMoveEvent;
/*     */ import org.bukkit.event.player.PlayerQuitEvent;
/*     */ import org.bukkit.inventory.ItemStack;
/*     */ import org.bukkit.inventory.meta.ItemMeta;
/*     */ import org.bukkit.plugin.Plugin;
/*     */ import org.bukkit.scheduler.BukkitRunnable;
/*     */ import org.bukkit.util.Vector;
/*     */ 
/*     */ 
/*     */ public class SchutzSchildListener
/*     */   implements Listener
/*     */ {
/*  27 */   HashMap<Player, BukkitRunnable> run = new HashMap<>();
/*     */   
/*     */   @EventHandler
/*     */   public void onInteractSchutzschild(PlayerInteractEvent e) {
/*  31 */     final Player p = e.getPlayer();
/*  32 */     if ((((e.getAction() == Action.RIGHT_CLICK_AIR) ? 1 : 0) | ((e.getAction() == Action.RIGHT_CLICK_BLOCK) ? 1 : 0)) != 0 && 
/*  33 */       p.getItemInHand().getType() == Material.EYE_OF_ENDER && p.hasPermission("lobby.vip") && (
/*  34 */       p.getItemInHand().getItemMeta().getDisplayName().equalsIgnoreCase("Â§5Schutzschild Â§8â”ƒ Â§cAus Â§8Ã— Â§7Rechtsklick") || 
/*  35 */       p.getItemInHand().getItemMeta().getDisplayName().equalsIgnoreCase("Â§5Schutzschild Â§8â”ƒ Â§aAn Â§8Ã— Â§7Rechtsklick"))) {
/*  36 */       e.setCancelled(true);
/*  37 */       if (this.run.containsKey(p)) {
/*     */         
/*  39 */         ItemStack item3 = new ItemStack(Material.EYE_OF_ENDER);
/*  40 */         ItemMeta meta3 = item3.getItemMeta();
/*  41 */         meta3.setDisplayName("Â§5Schutzschild Â§8â”ƒ Â§cAus Â§8Ã— Â§7Rechtsklick");
/*  42 */         item3.setItemMeta(meta3);
/*     */         
/*  44 */         p.getInventory().setItemInHand(item3);
/*     */         
/*  46 */         p.sendMessage(String.valueOf(String.valueOf(Data.CHAT_PREFIX)) + "Â§7Dein Schutzschild wurde Â§cDeaktiviert");
/*  47 */         p.playSound(p.getLocation(), Sound.CLICK, 1.0F, 1.0F);
/*  48 */         ((BukkitRunnable)this.run.get(p)).cancel();
/*  49 */         this.run.remove(p);
/*     */       }
/*  51 */       else if (!this.run.containsKey(p)) {
/*     */         
/*  53 */         ItemStack item3 = new ItemStack(Material.EYE_OF_ENDER);
/*  54 */         ItemMeta meta3 = item3.getItemMeta();
/*  55 */         meta3.setDisplayName("Â§5Schutzschild Â§8â”ƒ Â§aAn Â§8Ã— Â§7Rechtsklick");
/*  56 */         item3.setItemMeta(meta3);
/*     */         
/*  58 */         p.getInventory().setItemInHand(item3);
/*  59 */         this.run.put(p, new BukkitRunnable()
/*     */             {
/*     */               public void run()
/*     */               {
/*  63 */                 p.getWorld().playEffect(p.getLocation(), Effect.ENDER_SIGNAL, 10);
/*     */               }
/*     */             });
/*  66 */         ((BukkitRunnable)this.run.get(p)).runTaskTimer((Plugin)Main.getInstance(), 3L, 3L);
/*     */         
/*  68 */         p.sendMessage(String.valueOf(String.valueOf(Data.CHAT_PREFIX)) + "Â§7Dein Schutzschild wurde Â§aAktiviert");
/*  69 */         p.playSound(p.getLocation(), Sound.CLICK, 1.0F, 1.0F);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @EventHandler
/*     */   public void onQuit(PlayerQuitEvent e) {
/*  78 */     if (this.run.containsKey(e.getPlayer())) {
/*  79 */       ((BukkitRunnable)this.run.get(e.getPlayer())).cancel();
/*  80 */       this.run.remove(e.getPlayer());
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   @EventHandler
/*     */   public void onMove(PlayerMoveEvent e) {
/*  87 */     Player p = e.getPlayer();
/*     */     
/*  89 */     for (Player player : this.run.keySet()) {
/*  90 */       if (p != player && !p.hasPermission("lobby.bypass") && 
/*  91 */         p.getLocation().distance(player.getLocation()) <= 4.0D) {
/*     */         
/*  93 */         double Ax = p.getLocation().getX();
/*  94 */         double Ay = p.getLocation().getY();
/*  95 */         double Az = p.getLocation().getZ();
/*     */         
/*  97 */         double Bx = player.getLocation().getX();
/*  98 */         double By = player.getLocation().getY();
/*  99 */         double Bz = player.getLocation().getZ();
/*     */         
/* 101 */         double x = Ax - Bx;
/* 102 */         double y = Ay - By;
/* 103 */         double z = Az - Bz;
/*     */         
/* 105 */         Vector v = (new Vector(x, y, z)).normalize().multiply(1.0D).setY(0.3D);
/* 106 */         p.setVelocity(v);
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 111 */     if (this.run.containsKey(p))
/* 112 */       for (Entity entity : p.getNearbyEntities(4.0D, 4.0D, 4.0D)) {
/* 113 */         if (entity instanceof Player) {
/* 114 */           Player target = (Player)entity;
/* 115 */           if (p != target && 
/* 116 */             !target.hasPermission("lobby.bypass")) {
/*     */             
/* 118 */             double Ax = p.getLocation().getX();
/* 119 */             double Ay = p.getLocation().getY();
/* 120 */             double Az = p.getLocation().getZ();
/*     */             
/* 122 */             double Bx = target.getLocation().getX();
/* 123 */             double By = target.getLocation().getY();
/* 124 */             double Bz = target.getLocation().getZ();
/*     */             
/* 126 */             double x = Bx - Ax;
/* 127 */             double y = By - Ay;
/* 128 */             double z = Bz - Az;
/*     */             
/* 130 */             Vector v = (new Vector(x, y, z)).normalize().multiply(1.0D).setY(0.3D);
/* 131 */             target.setVelocity(v);
/*     */           } 
/*     */         } 
/*     */       }  
/*     */   }
/*     */ }


/* Location:              C:\Users\maxim\Desktop\Lobby.jar!\Listener\SchutzSchildListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */