/*    */ package Listener;
/*    */ 
/*    */ import Data.Data;
/*    */ import org.bukkit.Bukkit;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.EventHandler;
/*    */ import org.bukkit.event.Listener;
/*    */ import org.bukkit.event.player.PlayerCommandPreprocessEvent;
/*    */ 
/*    */ 
/*    */ public class ReloadListener
/*    */   implements Listener
/*    */ {
/*    */   @EventHandler
/*    */   public void ReloadEvent(PlayerCommandPreprocessEvent e) {
/* 16 */     Player p = e.getPlayer();
/* 17 */     if (p.hasPermission("lobby.admin") && (e.getMessage().equalsIgnoreCase("/rl") || e.getMessage().equalsIgnoreCase("/reload")))
/* 18 */       for (Player all : Bukkit.getOnlinePlayers()) {
/* 19 */         all.sendMessage(String.valueOf(String.valueOf(Data.CHAT_PREFIX)) + "Â§7Der Server wird reloadet");
/* 20 */         all.kickPlayer(String.valueOf(String.valueOf(Data.CHAT_PREFIX)) + "Â§7Der Server wird reloadet");
/* 21 */         Bukkit.reload();
/*    */       }  
/*    */   }
/*    */ }


/* Location:              C:\Users\maxim\Desktop\Lobby.jar!\Listener\ReloadListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */