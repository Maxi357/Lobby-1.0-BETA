/*    */ package Listener;
/*    */ 
/*    */ import Main.Main;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.EventHandler;
/*    */ import org.bukkit.event.Listener;
/*    */ import org.bukkit.event.inventory.InventoryClickEvent;
/*    */ 
/*    */ public class InventoryMoveListener
/*    */   implements Listener
/*    */ {
/*    */   private static Main pl;
/*    */   
/*    */   public InventoryMoveListener(Main main2) {
/* 15 */     pl = main2;
/*    */   }
/*    */ 
/*    */   
/*    */   @EventHandler
/*    */   public void InventoryMoveEvent(InventoryClickEvent e) {
/* 21 */     Player p = (Player)e.getWhoClicked();
/* 22 */     if (pl.buildmode.contains(p)) {
/* 23 */       e.setCancelled(false);
/*    */     } else {
/* 25 */       e.setCancelled(true);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\maxim\Desktop\Lobby.jar!\Listener\InventoryMoveListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */