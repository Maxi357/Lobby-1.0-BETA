/*    */ package Listener;
/*    */ 
/*    */ import Data.Data;
/*    */ import org.bukkit.Bukkit;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.EventHandler;
/*    */ import org.bukkit.event.EventPriority;
/*    */ import org.bukkit.event.Listener;
/*    */ import org.bukkit.event.player.PlayerCommandPreprocessEvent;
/*    */ import org.bukkit.help.HelpTopic;
/*    */ 
/*    */ 
/*    */ public class UnknownListener
/*    */   implements Listener
/*    */ {
/*    */   @EventHandler(priority = EventPriority.HIGHEST)
/*    */   public void UnknownEvent(PlayerCommandPreprocessEvent event) {
/* 18 */     if (!event.isCancelled()) {
/*    */       
/* 20 */       Player p = event.getPlayer();
/* 21 */       String msg = event.getMessage().split(" ")[0];
/* 22 */       HelpTopic topic = Bukkit.getServer().getHelpMap().getHelpTopic(msg);
/* 23 */       if (topic == null) {
/*    */         
/* 25 */         p.sendMessage(String.valueOf(String.valueOf(Data.CHAT_PREFIX)) + "Â§7Der Befehl wurde nicht gefunden");
/* 26 */         event.setCancelled(true);
/*    */       } 
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\maxim\Desktop\Lobby.jar!\Listener\UnknownListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */