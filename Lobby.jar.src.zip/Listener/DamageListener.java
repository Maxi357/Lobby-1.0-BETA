/*    */ package Listener;
/*    */ 
/*    */ import org.bukkit.event.EventHandler;
/*    */ import org.bukkit.event.Listener;
/*    */ import org.bukkit.event.entity.EntityDamageByEntityEvent;
/*    */ import org.bukkit.event.entity.EntityDamageEvent;
/*    */ 
/*    */ public class DamageListener
/*    */   implements Listener
/*    */ {
/*    */   @EventHandler
/*    */   public void DamageEvent(EntityDamageEvent e) {
/* 13 */     e.setCancelled(true);
/* 14 */     if (e.getCause().equals(EntityDamageEvent.DamageCause.FALL)) {
/* 15 */       e.setCancelled(true);
/*    */     }
/* 17 */     if (e.getCause().equals(EntityDamageEvent.DamageCause.FIRE)) {
/* 18 */       e.setCancelled(true);
/*    */     }
/* 20 */     if (e.getCause().equals(EntityDamageEvent.DamageCause.FIRE_TICK)) {
/* 21 */       e.setCancelled(true);
/*    */     }
/* 23 */     if (e.getCause().equals(EntityDamageEvent.DamageCause.VOID)) {
/* 24 */       e.setCancelled(true);
/*    */     }
/*    */   }
/*    */   
/*    */   @EventHandler
/*    */   public void DamageEvent1(EntityDamageByEntityEvent e) {
/* 30 */     e.setCancelled(true);
/*    */   }
/*    */ }


/* Location:              C:\Users\maxim\Desktop\Lobby.jar!\Listener\DamageListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */