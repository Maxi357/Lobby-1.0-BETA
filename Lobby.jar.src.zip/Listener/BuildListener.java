/*    */ package Listener;
/*    */ 
/*    */ import Main.Main;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.EventHandler;
/*    */ import org.bukkit.event.Listener;
/*    */ import org.bukkit.event.block.BlockBreakEvent;
/*    */ import org.bukkit.event.block.BlockPlaceEvent;
/*    */ 
/*    */ public class BuildListener
/*    */   implements Listener
/*    */ {
/*    */   private static Main pl;
/*    */   
/*    */   public BuildListener(Main main2) {
/* 16 */     pl = main2;
/*    */   }
/*    */ 
/*    */   
/*    */   @EventHandler
/*    */   public void BuildEvent(BlockBreakEvent e) {
/* 22 */     Player p = e.getPlayer();
/* 23 */     if (pl.buildmode.contains(p)) {
/* 24 */       e.setCancelled(false);
/*    */     } else {
/* 26 */       e.setCancelled(true);
/*    */     } 
/*    */   }
/*    */   @EventHandler
/*    */   public void BuildEvent1(BlockPlaceEvent e) {
/* 31 */     Player p = e.getPlayer();
/* 32 */     if (pl.buildmode.contains(p)) {
/* 33 */       e.setCancelled(false);
/*    */     } else {
/* 35 */       e.setCancelled(true);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\maxim\Desktop\Lobby.jar!\Listener\BuildListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */