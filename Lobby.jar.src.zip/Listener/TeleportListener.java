/*     */ package Listener;
/*     */ 
/*     */ import Data.Data;
/*     */ import Main.Main;
/*     */ import Methods.Settings;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.Material;
/*     */ import org.bukkit.Sound;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.event.EventHandler;
/*     */ import org.bukkit.event.Listener;
/*     */ import org.bukkit.event.block.Action;
/*     */ import org.bukkit.event.inventory.InventoryClickEvent;
/*     */ import org.bukkit.event.player.PlayerInteractEvent;
/*     */ import org.bukkit.inventory.Inventory;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TeleportListener
/*     */   implements Listener
/*     */ {
/*     */   private Main pl;
/*     */   Inventory inv;
/*     */   
/*     */   public TeleportListener(Main pl) {
/*  26 */     this.inv = Bukkit.createInventory(null, 27, "§8● §7Spielmodis §8●");
/*  27 */     this.pl = pl;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @EventHandler
/*     */   public void onInteractTeleporter(PlayerInteractEvent e) {
/*  36 */     Player p = e.getPlayer();
/*  37 */     if ((e.getAction().equals(Action.RIGHT_CLICK_BLOCK) || e.getAction().equals(Action.RIGHT_CLICK_AIR)) && 
/*  38 */       e.getItem().getItemMeta().getDisplayName().equalsIgnoreCase("§eNavigator §8× §7Rechtsklick") && 
/*  39 */       e.getItem().getType() == Material.COMPASS) {
/*     */       
/*  41 */       this.inv.setItem(26, Settings.CreateItemwithID(Material.BARRIER, 0, 1, "§cComing-Soon"));
/*  42 */       this.inv.setItem(25, Settings.CreateItemwithID(Material.STAINED_GLASS_PANE, 7, 1, " "));
/*  43 */       this.inv.setItem(24, Settings.CreateItemwithID(Material.STAINED_GLASS_PANE, 7, 1, " "));
/*  44 */       this.inv.setItem(23, Settings.CreateItemwithID(Material.STAINED_GLASS_PANE, 7, 1, " "));
/*  45 */       this.inv.setItem(22, Settings.CreateItemwithID(Material.STICK, 0, 1, "§2KnockOut"));
/*  46 */       this.inv.setItem(21, Settings.CreateItemwithID(Material.STAINED_GLASS_PANE, 7, 1, " "));
/*  47 */       this.inv.setItem(20, Settings.CreateItemwithID(Material.STAINED_GLASS_PANE, 7, 1, " "));
/*  48 */       this.inv.setItem(19, Settings.CreateItemwithID(Material.STAINED_GLASS_PANE, 7, 1, " "));
/*  49 */       this.inv.setItem(18, Settings.CreateItemwithID(Material.BARRIER, 0, 1, "§cComing-Soon"));
/*  50 */       this.inv.setItem(17, Settings.CreateItemwithID(Material.STAINED_GLASS_PANE, 7, 1, " "));
/*  51 */       this.inv.setItem(16, Settings.CreateItemwithID(Material.IRON_PICKAXE, 0, 1, "§dSkyWars"));
/*  52 */       this.inv.setItem(15, Settings.CreateItemwithID(Material.STAINED_GLASS_PANE, 7, 1, " "));
/*  53 */       this.inv.setItem(14, Settings.CreateItemwithID(Material.STAINED_GLASS_PANE, 7, 1, " "));
/*  54 */       this.inv.setItem(13, Settings.CreateItemwithID(Material.MAGMA_CREAM, 0, 1, "§aSpawn"));
/*  55 */       this.inv.setItem(12, Settings.CreateItemwithID(Material.STAINED_GLASS_PANE, 7, 1, " "));
/*  56 */       this.inv.setItem(11, Settings.CreateItemwithID(Material.STAINED_GLASS_PANE, 7, 1, " "));
/*  57 */       this.inv.setItem(10, Settings.CreateItemwithID(Material.IRON_SWORD, 0, 1, "§bSkyPvP"));
/*  58 */       this.inv.setItem(9, Settings.CreateItemwithID(Material.STAINED_GLASS_PANE, 7, 1, " "));
/*  59 */       this.inv.setItem(8, Settings.CreateItemwithID(Material.BARRIER, 0, 1, "§cComing-Soon"));
/*  60 */       this.inv.setItem(7, Settings.CreateItemwithID(Material.STAINED_GLASS_PANE, 7, 1, " "));
/*  61 */       this.inv.setItem(6, Settings.CreateItemwithID(Material.STAINED_GLASS_PANE, 7, 1, " "));
/*  62 */       this.inv.setItem(5, Settings.CreateItemwithID(Material.STAINED_GLASS_PANE, 7, 1, " "));
/*  63 */       this.inv.setItem(4, Settings.CreateItemwithID(Material.GOLD_BLOCK, 0, 1, "§6Community"));
/*  64 */       this.inv.setItem(3, Settings.CreateItemwithID(Material.STAINED_GLASS_PANE, 7, 1, " "));
/*  65 */       this.inv.setItem(2, Settings.CreateItemwithID(Material.STAINED_GLASS_PANE, 7, 1, " "));
/*  66 */       this.inv.setItem(1, Settings.CreateItemwithID(Material.STAINED_GLASS_PANE, 7, 1, " "));
/*  67 */       this.inv.setItem(0, Settings.CreateItemwithID(Material.BARRIER, 0, 1, "§cComing-Soon"));
/*     */       
/*  69 */       p.openInventory(this.inv);
/*  70 */       p.playSound(p.getLocation(), Sound.CLICK, 1.0F, 1.0F);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   @EventHandler
/*     */   public void onClickInv(InventoryClickEvent e) {
/*  77 */     Player p = (Player)e.getWhoClicked();
/*     */     
/*  79 */     if (e.getClickedInventory().getName().equalsIgnoreCase("§8● §7Spielmodis §8●")) {
/*  80 */       e.setCancelled(true);
/*     */     }
/*  82 */     if (e.getClickedInventory().getName().equalsIgnoreCase("§8● §7Spielmodis §8●") && 
/*  83 */       e.getCurrentItem().getItemMeta().getDisplayName().equalsIgnoreCase("§aSpawn")) {
/*  84 */       if (this.pl.getConfig().isSet("spawn.world")) {
/*  85 */         p.teleport(this.pl.getspawn());
/*  86 */         p.playSound(p.getLocation(), Sound.ENDERDRAGON_WINGS, 1.0F, 1.0F);
/*  87 */         e.setCancelled(true);
/*  88 */         p.closeInventory();
/*     */       } else {
/*  90 */         e.setCancelled(true);
/*  91 */         p.sendMessage(String.valueOf(String.valueOf(Data.CHAT_PREFIX)) + "§7Der Warp wurde nicht gefunden");
/*     */       } 
/*     */     }
/*     */     
/*  95 */     if (e.getClickedInventory().getName().equalsIgnoreCase("§8● §7Spielmodis §8●") && 
/*  96 */       e.getCurrentItem().getItemMeta().getDisplayName().equalsIgnoreCase("§bSkyPvP")) {
/*  97 */       if (this.pl.getConfig().isSet("spawn.skypvp.world")) {
/*  98 */         p.teleport(this.pl.getskypvploc());
/*  99 */         p.playSound(p.getLocation(), Sound.ENDERDRAGON_WINGS, 1.0F, 1.0F);
/* 100 */         e.setCancelled(true);
/* 101 */         p.closeInventory();
/*     */       } else {
/* 103 */         e.setCancelled(true);
/* 104 */         p.sendMessage(String.valueOf(String.valueOf(Data.CHAT_PREFIX)) + "§7Der Warp wurde nicht gefunden");
/*     */       } 
/*     */     }
/*     */     
/* 108 */     if (e.getClickedInventory().getName().equalsIgnoreCase("§8● §7Spielmodis §8●") && 
/* 109 */       e.getCurrentItem().getItemMeta().getDisplayName().equalsIgnoreCase("§2KnockOut")) {
/* 110 */       if (this.pl.getConfig().isSet("spawn.knockout.world")) {
/* 111 */         p.teleport(this.pl.getknockoutloc());
/* 112 */         p.playSound(p.getLocation(), Sound.ENDERDRAGON_WINGS, 1.0F, 1.0F);
/* 113 */         e.setCancelled(true);
/* 114 */         p.closeInventory();
/*     */       } else {
/* 116 */         e.setCancelled(true);
/* 117 */         p.sendMessage(String.valueOf(String.valueOf(Data.CHAT_PREFIX)) + "§7Der Warp wurde nicht gefunden");
/*     */       } 
/*     */     }
/*     */     
/* 121 */     if (e.getClickedInventory().getName().equalsIgnoreCase("§8● §7Spielmodis §8●") && 
/* 122 */       e.getCurrentItem().getItemMeta().getDisplayName().equalsIgnoreCase("§dSkyWars")) {
/* 123 */       if (this.pl.getConfig().isSet("spawn.SkyWars.world")) {
/* 124 */         p.teleport(this.pl.getskywarsloc1());
/* 125 */         p.playSound(p.getLocation(), Sound.ENDERDRAGON_WINGS, 1.0F, 1.0F);
/* 126 */         e.setCancelled(true);
/* 127 */         p.closeInventory();
/*     */       } else {
/* 129 */         e.setCancelled(true);
/* 130 */         p.sendMessage(String.valueOf(String.valueOf(Data.CHAT_PREFIX)) + "§7Der Warp wurde nicht gefunden");
/*     */       } 
/*     */     }
/*     */     
/* 134 */     if (e.getClickedInventory().getName().equalsIgnoreCase("§8● §7Spielmodis §8●") && 
/* 135 */       e.getCurrentItem().getItemMeta().getDisplayName().equalsIgnoreCase("§cComing-Soon")) {
/* 136 */       if (this.pl.getConfig().isSet("spawn.comingsoon.world")) {
/* 137 */         p.teleport(this.pl.getcomingsoonloc());
/* 138 */         p.playSound(p.getLocation(), Sound.ENDERDRAGON_WINGS, 1.0F, 1.0F);
/* 139 */         e.setCancelled(true);
/* 140 */         p.closeInventory();
/*     */       } else {
/* 142 */         e.setCancelled(true);
/* 143 */         p.sendMessage(String.valueOf(String.valueOf(Data.CHAT_PREFIX)) + "§7Der Spielmodus ist in §c§lIn Arbeit");
/*     */       } 
/*     */     }
/*     */     
/* 147 */     if (e.getClickedInventory().getName().equalsIgnoreCase("§8● §7Spielmodis §8●") && 
/* 148 */       e.getCurrentItem().getItemMeta().getDisplayName().equalsIgnoreCase("§6Community"))
/* 149 */       if (this.pl.getConfig().isSet("spawn.community.world")) {
/* 150 */         p.teleport(this.pl.getcommunityloc());
/* 151 */         p.playSound(p.getLocation(), Sound.ENDERDRAGON_WINGS, 1.0F, 1.0F);
/* 152 */         e.setCancelled(true);
/* 153 */         p.closeInventory();
/*     */       } else {
/* 155 */         e.setCancelled(true);
/* 156 */         p.sendMessage(String.valueOf(String.valueOf(Data.CHAT_PREFIX)) + "§7Der Warp wurde nicht gefunden");
/*     */       }  
/*     */   }
/*     */ }


/* Location:              C:\Users\maxim\Desktop\Lobby.jar!\Listener\TeleportListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */