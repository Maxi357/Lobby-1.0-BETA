/*    */ package Listener;
/*    */ 
/*    */ import org.bukkit.Bukkit;
/*    */ import org.bukkit.Location;
/*    */ import org.bukkit.Material;
/*    */ import org.bukkit.Sound;
/*    */ import org.bukkit.entity.Fish;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.EventHandler;
/*    */ import org.bukkit.event.EventPriority;
/*    */ import org.bukkit.event.Listener;
/*    */ import org.bukkit.event.player.PlayerFishEvent;
/*    */ import org.bukkit.util.Vector;
/*    */ 
/*    */ public class EnterhakenListener
/*    */   implements Listener {
/*    */   @EventHandler(priority = EventPriority.NORMAL, ignoreCancelled = true)
/*    */   public void onFish(PlayerFishEvent event) {
/* 19 */     Player player = event.getPlayer();
/* 20 */     Fish h = event.getHook();
/* 21 */     if (event.getState() == PlayerFishEvent.State.IN_GROUND || 
/* 22 */       event.getState().equals(PlayerFishEvent.State.CAUGHT_ENTITY) || 
/* 23 */       event.getState().equals(PlayerFishEvent.State.FAILED_ATTEMPT))
/*    */     {
/* 25 */       if (Bukkit.getWorld(event.getPlayer().getWorld().getName()).getBlockAt(h.getLocation().getBlockX(), 
/* 26 */           h.getLocation().getBlockY() - 1, h.getLocation().getBlockZ())
/* 27 */         .getType() != Material.AIR) {
/* 28 */         Location lc = player.getLocation();
/* 29 */         Location to = event.getHook().getLocation();
/*    */         
/* 31 */         lc.setY(lc.getY() + 0.5D);
/* 32 */         player.teleport(lc);
/* 33 */         player.playSound(player.getLocation(), Sound.ENDERDRAGON_WINGS, 1.0F, 1.0F);
/*    */         
/* 35 */         double g = -0.08D;
/* 36 */         double d = to.distance(lc);
/* 37 */         double t = d;
/* 38 */         double v_x = (1.0D + 0.07D * t) * (to.getX() - lc.getX()) / t;
/* 39 */         double v_y = (1.0D + 0.03D * t) * (to.getY() - lc.getY()) / t - 0.5D * g * t;
/* 40 */         double v_z = (1.0D + 0.07D * t) * (to.getZ() - lc.getZ()) / t;
/*    */         
/* 42 */         Vector v = player.getVelocity();
/* 43 */         v.setX(v_x);
/* 44 */         v.setY(v_y);
/* 45 */         v.setZ(v_z);
/* 46 */         player.setVelocity(v);
/*    */       } 
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\maxim\Desktop\Lobby.jar!\Listener\EnterhakenListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */