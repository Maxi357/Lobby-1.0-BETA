/*    */ package Listener;
/*    */ 
/*    */ import Main.Main;
/*    */ import Methods.Items;
/*    */ import Scoreboard.Scoreboard;
/*    */ import org.bukkit.Bukkit;
/*    */ import org.bukkit.GameMode;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.EventHandler;
/*    */ import org.bukkit.event.Listener;
/*    */ import org.bukkit.event.player.PlayerJoinEvent;
/*    */ 
/*    */ public class JoinListener
/*    */   implements Listener
/*    */ {
/*    */   @EventHandler
/*    */   public void JoinEvent(PlayerJoinEvent e) {
/* 18 */     Player p = e.getPlayer();
/*    */     
/* 20 */     p.getInventory().clear();
/* 21 */     p.setGameMode(GameMode.ADVENTURE);
/* 22 */     p.setAllowFlight(false);
/* 23 */     p.setHealth(1.5D);
/* 24 */     p.setMaxHealth(1.5D);
/* 25 */     p.setFoodLevel(20);
/* 26 */     p.setLevel(2017);
/* 27 */     p.setExp(0.0F);
/* 28 */     p.getInventory().setArmorContents(null);
/* 29 */     p.getActivePotionEffects().clear();
/* 30 */     Items.giveItems(p);
/* 31 */     p.teleport(Main.getInstance().getspawn());
/*    */     
/* 33 */     e.setJoinMessage(null);
/*    */     
/* 35 */     for (Player all : Bukkit.getOnlinePlayers())
/* 36 */       Scoreboard.setScoreboard(all); 
/*    */   }
/*    */ }


/* Location:              C:\Users\maxim\Desktop\Lobby.jar!\Listener\JoinListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */