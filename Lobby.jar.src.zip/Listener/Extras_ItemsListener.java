/*     */ package Listener;
/*     */ 
/*     */ import Data.Data;
/*     */ import Methods.Settings;
/*     */ import Special.BalloonMover;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.Material;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.event.EventHandler;
/*     */ import org.bukkit.event.Listener;
/*     */ import org.bukkit.event.inventory.InventoryClickEvent;
/*     */ import org.bukkit.inventory.Inventory;
/*     */ import org.bukkit.inventory.InventoryHolder;
/*     */ import org.bukkit.inventory.ItemStack;
/*     */ 
/*     */ public class Extras_ItemsListener
/*     */   implements Listener {
/*     */   @EventHandler
/*     */   public void onClickBallons(InventoryClickEvent e) {
/*  20 */     Player p = (Player)e.getWhoClicked();
/*  21 */     if (e.getCurrentItem().getType() == Material.STAINED_CLAY)
/*  22 */       if (p.hasPermission("lobby.premium")) {
/*  23 */         Inventory inv = Bukkit.createInventory((InventoryHolder)p, 27, "§8● §7Ballons §8●");
/*  24 */         inv.setItem(0, Settings.CreateItemwithID(Material.STAINED_GLASS_PANE, 7, 1, " "));
/*  25 */         inv.setItem(1, Settings.CreateItemwithID(Material.STAINED_GLASS_PANE, 7, 1, " "));
/*  26 */         inv.setItem(2, Settings.CreateItemwithID(Material.STAINED_GLASS_PANE, 7, 1, " "));
/*  27 */         inv.setItem(3, Settings.CreateItemwithID(Material.STAINED_GLASS_PANE, 7, 1, " "));
/*  28 */         inv.setItem(4, Settings.CreateItemwithID(Material.STAINED_GLASS_PANE, 7, 1, " "));
/*  29 */         inv.setItem(5, Settings.CreateItemwithID(Material.STAINED_GLASS_PANE, 7, 1, " "));
/*  30 */         inv.setItem(6, Settings.CreateItemwithID(Material.STAINED_GLASS_PANE, 7, 1, " "));
/*  31 */         inv.setItem(7, Settings.CreateItemwithID(Material.STAINED_GLASS_PANE, 7, 1, " "));
/*  32 */         inv.setItem(8, Settings.CreateItemwithID(Material.STAINED_GLASS_PANE, 7, 1, " "));
/*  33 */         inv.setItem(9, Settings.CreateItemwithID(Material.STAINED_GLASS_PANE, 7, 1, " "));
/*  34 */         inv.setItem(10, Settings.CreateItemwithID(Material.STAINED_CLAY, 14, 1, "§cRoter §eBallon"));
/*  35 */         inv.setItem(11, Settings.CreateItemwithID(Material.STAINED_GLASS_PANE, 7, 1, " "));
/*  36 */         inv.setItem(12, Settings.CreateItemwithID(Material.STAINED_CLAY, 11, 1, "§9Blauer §eBallon"));
/*  37 */         inv.setItem(13, Settings.CreateItemwithID(Material.STAINED_GLASS_PANE, 7, 1, " "));
/*  38 */         inv.setItem(14, Settings.CreateItemwithID(Material.STAINED_CLAY, 5, 1, "§aGrüner §eBallon"));
/*  39 */         inv.setItem(15, Settings.CreateItemwithID(Material.STAINED_GLASS_PANE, 7, 1, " "));
/*  40 */         inv.setItem(16, Settings.CreateItemwithID(Material.STAINED_CLAY, 4, 1, "§eGelber Ballon"));
/*  41 */         inv.setItem(17, Settings.CreateItemwithID(Material.STAINED_GLASS_PANE, 7, 1, " "));
/*  42 */         inv.setItem(18, Settings.CreateItemwithID(Material.STAINED_GLASS_PANE, 7, 1, " "));
/*  43 */         inv.setItem(19, Settings.CreateItemwithID(Material.STAINED_GLASS_PANE, 7, 1, " "));
/*  44 */         inv.setItem(20, Settings.CreateItemwithID(Material.STAINED_GLASS_PANE, 7, 1, " "));
/*  45 */         inv.setItem(21, Settings.CreateItemwithID(Material.STAINED_GLASS_PANE, 7, 1, " "));
/*  46 */         inv.setItem(22, Settings.CreateItemwithID(Material.STAINED_GLASS_PANE, 7, 1, " "));
/*  47 */         inv.setItem(23, Settings.CreateItemwithID(Material.STAINED_GLASS_PANE, 7, 1, " "));
/*  48 */         inv.setItem(24, Settings.CreateItemwithID(Material.STAINED_GLASS_PANE, 7, 1, " "));
/*  49 */         inv.setItem(25, Settings.CreateItemwithID(Material.STAINED_GLASS_PANE, 7, 1, " "));
/*  50 */         inv.setItem(26, Settings.CreateItemwithID(Material.BARRIER, 1, 1, "§cBallon entfernen"));
/*  51 */         p.openInventory(inv);
/*     */       } else {
/*  53 */         p.sendMessage(String.valueOf(String.valueOf(Data.CHAT_PREFIX)) + "§7Du benötigst mindestens den §6§lPremium§r §7Rang");
/*     */       }  
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void onClick(InventoryClickEvent e) {
/*  59 */     Player p = (Player)e.getWhoClicked();
/*     */     
/*  61 */     if (e.getInventory().getName().equalsIgnoreCase("§8● §7Hüte §8●")) {
/*  62 */       e.setCancelled(true);
/*  63 */       if (e.getCurrentItem().getType() == Material.PUMPKIN) {
/*  64 */         p.getInventory().setHelmet(Settings.CreateItemwithID(Material.PUMPKIN, 1, 1, "§eKürbis"));
/*  65 */         p.sendMessage(String.valueOf(String.valueOf(Data.CHAT_PREFIX)) + "§7Du hast den Hut §eKürbis §7ausgewählt");
/*     */       } 
/*  67 */       if (e.getCurrentItem().getType() == Material.LEAVES) {
/*  68 */         p.getInventory().setHelmet(Settings.CreateItemwithID(Material.LEAVES, 1, 1, "§eBlätter"));
/*  69 */         p.sendMessage(String.valueOf(String.valueOf(Data.CHAT_PREFIX)) + "§7Du hast den Hut §eBlätter §7ausgewählt");
/*     */       } 
/*  71 */       if (e.getCurrentItem().getType() == Material.GOLD_BLOCK) {
/*  72 */         p.getInventory().setHelmet(Settings.CreateItemwithID(Material.GOLD_BLOCK, 1, 1, "§eGoldblock"));
/*  73 */         p.sendMessage(String.valueOf(String.valueOf(Data.CHAT_PREFIX)) + "§7Du hast den Hut §eGoldblock §7ausgewählt");
/*     */       } 
/*  75 */       if (e.getCurrentItem().getType() == Material.TNT) {
/*  76 */         p.getInventory().setHelmet(Settings.CreateItemwithID(Material.TNT, 1, 1, "§eTNT"));
/*  77 */         p.sendMessage(String.valueOf(String.valueOf(Data.CHAT_PREFIX)) + "§7Du hast den Hut §eTnT §7ausgewählt");
/*     */       } 
/*  79 */       if (e.getCurrentItem().getType() == Material.NOTE_BLOCK) {
/*  80 */         p.getInventory().setHelmet(Settings.CreateItemwithID(Material.NOTE_BLOCK, 1, 1, "§eMusikblock"));
/*  81 */         p.sendMessage(String.valueOf(String.valueOf(Data.CHAT_PREFIX)) + "§7Du hast den Hut §eMusikblock §7ausgewählt");
/*     */       } 
/*  83 */       if (e.getCurrentItem().getItemMeta().getDisplayName().equalsIgnoreCase("§cHüte entfernen")) {
/*  84 */         p.getInventory().setHelmet(null);
/*  85 */         p.sendMessage(String.valueOf(String.valueOf(Data.CHAT_PREFIX)) + "§7Du hast dein §eHut §7entfernt");
/*     */       } 
/*     */     } 
/*     */     
/*  89 */     if (e.getInventory().getName().equalsIgnoreCase("§8● §7Extras §8●")) {
/*  90 */       e.setCancelled(true);
/*  91 */       if (e.getCurrentItem().getType() == Material.PUMPKIN) {
/*  92 */         Inventory inv = Bukkit.createInventory((InventoryHolder)p, 27, "§8● §7Hüte §8●");
/*  93 */         inv.setItem(0, Settings.CreateItemwithID(Material.STAINED_GLASS_PANE, 7, 1, " "));
/*  94 */         inv.setItem(1, Settings.CreateItemwithID(Material.STAINED_GLASS_PANE, 7, 1, " "));
/*  95 */         inv.setItem(2, Settings.CreateItemwithID(Material.STAINED_GLASS_PANE, 7, 1, " "));
/*  96 */         inv.setItem(3, Settings.CreateItemwithID(Material.STAINED_GLASS_PANE, 7, 1, " "));
/*  97 */         inv.setItem(4, Settings.CreateItemwithID(Material.STAINED_GLASS_PANE, 7, 1, " "));
/*  98 */         inv.setItem(5, Settings.CreateItemwithID(Material.STAINED_GLASS_PANE, 7, 1, " "));
/*  99 */         inv.setItem(6, Settings.CreateItemwithID(Material.STAINED_GLASS_PANE, 7, 1, " "));
/* 100 */         inv.setItem(7, Settings.CreateItemwithID(Material.STAINED_GLASS_PANE, 7, 1, " "));
/* 101 */         inv.setItem(8, Settings.CreateItemwithID(Material.STAINED_GLASS_PANE, 7, 1, " "));
/* 102 */         inv.setItem(9, Settings.CreateItemwithID(Material.PUMPKIN, 1, 1, "§eKürbis"));
/* 103 */         inv.setItem(10, Settings.CreateItemwithID(Material.STAINED_GLASS_PANE, 7, 1, " "));
/* 104 */         inv.setItem(11, Settings.CreateItemwithID(Material.LEAVES, 1, 1, "§eBlätter"));
/* 105 */         inv.setItem(12, Settings.CreateItemwithID(Material.STAINED_GLASS_PANE, 7, 1, " "));
/* 106 */         inv.setItem(13, Settings.CreateItemwithID(Material.GOLD_BLOCK, 1, 1, "§eGoldblock"));
/* 107 */         inv.setItem(14, Settings.CreateItemwithID(Material.STAINED_GLASS_PANE, 7, 1, " "));
/* 108 */         inv.setItem(15, Settings.CreateItemwithID(Material.TNT, 1, 1, "§eTNT"));
/* 109 */         inv.setItem(16, Settings.CreateItemwithID(Material.STAINED_GLASS_PANE, 7, 1, " "));
/* 110 */         inv.setItem(17, Settings.CreateItemwithID(Material.NOTE_BLOCK, 1, 1, "§eMusikbox"));
/* 111 */         inv.setItem(18, Settings.CreateItemwithID(Material.STAINED_GLASS_PANE, 7, 1, " "));
/* 112 */         inv.setItem(19, Settings.CreateItemwithID(Material.STAINED_GLASS_PANE, 7, 1, " "));
/* 113 */         inv.setItem(20, Settings.CreateItemwithID(Material.STAINED_GLASS_PANE, 7, 1, " "));
/* 114 */         inv.setItem(21, Settings.CreateItemwithID(Material.STAINED_GLASS_PANE, 7, 1, " "));
/* 115 */         inv.setItem(22, Settings.CreateItemwithID(Material.STAINED_GLASS_PANE, 7, 1, " "));
/* 116 */         inv.setItem(23, Settings.CreateItemwithID(Material.STAINED_GLASS_PANE, 7, 1, " "));
/* 117 */         inv.setItem(24, Settings.CreateItemwithID(Material.STAINED_GLASS_PANE, 7, 1, " "));
/* 118 */         inv.setItem(25, Settings.CreateItemwithID(Material.STAINED_GLASS_PANE, 7, 1, " "));
/* 119 */         inv.setItem(26, Settings.CreateItemwithID(Material.BARRIER, 1, 1, "§cHüte entfernen"));
/* 120 */         p.openInventory(inv);
/*     */       } 
/*     */     } 
/* 123 */     if (e.getCurrentItem().getItemMeta().getDisplayName().equalsIgnoreCase("§cRoter §eBallon")) {
/* 124 */       ItemStack s = new ItemStack(Material.STAINED_CLAY, 1, (short)14);
/* 125 */       BalloonMover.instance.resetBalloon(p, s);
/* 126 */       p.sendMessage(String.valueOf(String.valueOf(Data.CHAT_PREFIX)) + "§7Du hast den §cRoten §eBallon §7ausgewählt");
/*     */     } 
/* 128 */     if (e.getCurrentItem().getItemMeta().getDisplayName().equalsIgnoreCase("§9Blauer §eBallon")) {
/* 129 */       ItemStack s = new ItemStack(Material.STAINED_CLAY, 1, (short)11);
/* 130 */       BalloonMover.instance.resetBalloon(p, s);
/* 131 */       p.sendMessage(String.valueOf(String.valueOf(Data.CHAT_PREFIX)) + "§7Du hast den §9Blauen §eBallon §7ausgewählt");
/*     */     } 
/* 133 */     if (e.getCurrentItem().getItemMeta().getDisplayName().equalsIgnoreCase("§aGrüner §eBallon")) {
/* 134 */       ItemStack s = new ItemStack(Material.STAINED_CLAY, 1, (short)5);
/* 135 */       BalloonMover.instance.resetBalloon(p, s);
/* 136 */       p.sendMessage(String.valueOf(String.valueOf(Data.CHAT_PREFIX)) + "§7Du hast den §aGrünen §eBallon §7ausgewählt");
/*     */     } 
/* 138 */     if (e.getCurrentItem().getItemMeta().getDisplayName().equalsIgnoreCase("§eGelber Ballon")) {
/* 139 */       ItemStack s = new ItemStack(Material.STAINED_CLAY, 1, (short)4);
/* 140 */       BalloonMover.instance.resetBalloon(p, s);
/* 141 */       p.sendMessage(String.valueOf(String.valueOf(Data.CHAT_PREFIX)) + "§7Du hast den §eGelben §eBallon §7ausgewählt");
/*     */     } 
/* 143 */     if (e.getCurrentItem().getItemMeta().getDisplayName().equalsIgnoreCase("§cBallon entfernen")) {
/* 144 */       BalloonMover.instance.resetBalloon(p);
/* 145 */       p.sendMessage(String.valueOf(String.valueOf(Data.CHAT_PREFIX)) + "§7Du hast deinen §eBallon §7entfernt");
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\maxim\Desktop\Lobby.jar!\Listener\Extras_ItemsListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */