/*     */ package Listener;
/*     */ 
/*     */ import Data.Data;
/*     */ import Methods.Settings;
/*     */ import java.util.ArrayList;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.Material;
/*     */ import org.bukkit.Sound;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.event.EventHandler;
/*     */ import org.bukkit.event.Listener;
/*     */ import org.bukkit.event.block.Action;
/*     */ import org.bukkit.event.inventory.InventoryClickEvent;
/*     */ import org.bukkit.event.player.PlayerInteractEvent;
/*     */ import org.bukkit.inventory.Inventory;
/*     */ import org.bukkit.potion.PotionEffect;
/*     */ import org.bukkit.potion.PotionEffectType;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HideListener
/*     */   implements Listener
/*     */ {
/*  24 */   Inventory inv = Bukkit.createInventory(null, 27, "§8● §7Spieler Verstecken §8●");
/*  25 */   ArrayList<Player> inShowPlayer = new ArrayList<>();
/*  26 */   ArrayList<Player> inHidePlayer = new ArrayList<>();
/*     */ 
/*     */   
/*     */   @EventHandler
/*     */   public void onInteract(PlayerInteractEvent e) {
/*  31 */     Player p = e.getPlayer();
/*  32 */     if ((e.getAction().equals(Action.RIGHT_CLICK_BLOCK) || e.getAction().equals(Action.RIGHT_CLICK_AIR)) && 
/*  33 */       e.getMaterial().equals(Material.BLAZE_ROD) && 
/*  34 */       e.getItem().getItemMeta().getDisplayName().equalsIgnoreCase("§9Spieler-Verstecken §8× §7Rechtsklick")) {
/*     */       
/*  36 */       this.inv.setItem(0, Settings.CreateItemwithID(Material.STAINED_GLASS_PANE, 7, 1, " "));
/*  37 */       this.inv.setItem(1, Settings.CreateItemwithID(Material.STAINED_GLASS_PANE, 7, 1, " "));
/*  38 */       this.inv.setItem(2, Settings.CreateItemwithID(Material.STAINED_GLASS_PANE, 7, 1, " "));
/*  39 */       this.inv.setItem(3, Settings.CreateItemwithID(Material.STAINED_GLASS_PANE, 7, 1, " "));
/*  40 */       this.inv.setItem(4, Settings.CreateItemwithID(Material.STAINED_GLASS_PANE, 7, 1, " "));
/*  41 */       this.inv.setItem(5, Settings.CreateItemwithID(Material.STAINED_GLASS_PANE, 7, 1, " "));
/*  42 */       this.inv.setItem(6, Settings.CreateItemwithID(Material.STAINED_GLASS_PANE, 7, 1, " "));
/*  43 */       this.inv.setItem(7, Settings.CreateItemwithID(Material.STAINED_GLASS_PANE, 7, 1, " "));
/*  44 */       this.inv.setItem(8, Settings.CreateItemwithID(Material.STAINED_GLASS_PANE, 7, 1, " "));
/*  45 */       this.inv.setItem(9, Settings.CreateItemwithID(Material.STAINED_GLASS_PANE, 7, 1, " "));
/*  46 */       this.inv.setItem(11, Settings.CreateItemwithID(Material.INK_SACK, 10, 1, "§aSpieler Anzeigen"));
/*  47 */       this.inv.setItem(10, Settings.CreateItemwithID(Material.STAINED_GLASS_PANE, 7, 1, " "));
/*  48 */       this.inv.setItem(12, Settings.CreateItemwithID(Material.STAINED_GLASS_PANE, 7, 1, " "));
/*  49 */       this.inv.setItem(13, Settings.CreateItemwithID(Material.INK_SACK, 5, 1, "§5Nur Teamitglieder und YouTuber Anzeigen"));
/*  50 */       this.inv.setItem(14, Settings.CreateItemwithID(Material.STAINED_GLASS_PANE, 7, 1, " "));
/*  51 */       this.inv.setItem(16, Settings.CreateItemwithID(Material.STAINED_GLASS_PANE, 7, 1, " "));
/*  52 */       this.inv.setItem(15, Settings.CreateItemwithID(Material.INK_SACK, 1, 1, "§cSpieler Verstecken"));
/*  53 */       this.inv.setItem(17, Settings.CreateItemwithID(Material.STAINED_GLASS_PANE, 7, 1, " "));
/*  54 */       this.inv.setItem(18, Settings.CreateItemwithID(Material.STAINED_GLASS_PANE, 7, 1, " "));
/*  55 */       this.inv.setItem(19, Settings.CreateItemwithID(Material.STAINED_GLASS_PANE, 7, 1, " "));
/*  56 */       this.inv.setItem(20, Settings.CreateItemwithID(Material.STAINED_GLASS_PANE, 7, 1, " "));
/*  57 */       this.inv.setItem(21, Settings.CreateItemwithID(Material.STAINED_GLASS_PANE, 7, 1, " "));
/*  58 */       this.inv.setItem(22, Settings.CreateItemwithID(Material.STAINED_GLASS_PANE, 7, 1, " "));
/*  59 */       this.inv.setItem(23, Settings.CreateItemwithID(Material.STAINED_GLASS_PANE, 7, 1, " "));
/*  60 */       this.inv.setItem(24, Settings.CreateItemwithID(Material.STAINED_GLASS_PANE, 7, 1, " "));
/*  61 */       this.inv.setItem(25, Settings.CreateItemwithID(Material.STAINED_GLASS_PANE, 7, 1, " "));
/*  62 */       this.inv.setItem(26, Settings.CreateItemwithID(Material.STAINED_GLASS_PANE, 7, 1, " "));
/*  63 */       p.openInventory(this.inv);
/*  64 */       p.playSound(p.getLocation(), Sound.CLICK, 1.0F, 1.0F);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   @EventHandler
/*     */   public void onClick(InventoryClickEvent e) {
/*  71 */     Player p = (Player)e.getWhoClicked();
/*  72 */     if (e.getClickedInventory().getName().equalsIgnoreCase("§aVerstecke deine Spieler")) {
/*  73 */       e.setCancelled(true);
/*     */     }
/*  75 */     if (e.getCurrentItem().getItemMeta().getDisplayName().equalsIgnoreCase("§aSpieler Anzeigen")) {
/*     */       
/*  77 */       if (this.inShowPlayer.contains(p))
/*     */       {
/*  79 */         p.sendMessage(String.valueOf(String.valueOf(Data.CHAT_PREFIX)) + "§7Die Spieler werden bereits Angezeigt");
/*  80 */         p.playSound(p.getLocation(), Sound.ITEM_BREAK, 1.0F, 1.0F);
/*  81 */         p.closeInventory();
/*     */       }
/*     */       else
/*     */       {
/*  85 */         this.inShowPlayer.add(p);
/*  86 */         this.inHidePlayer.remove(p);
/*  87 */         showPlayers(p);
/*  88 */         p.addPotionEffect(new PotionEffect(PotionEffectType.BLINDNESS, 30, 999999));
/*  89 */         p.playSound(p.getLocation(), Sound.LEVEL_UP, 1.0F, 1.0F);
/*  90 */         p.closeInventory();
/*  91 */         p.sendMessage(String.valueOf(String.valueOf(Data.CHAT_PREFIX)) + "§7Die Spieler werden wieder Angezeigt");
/*     */       }
/*     */     
/*  94 */     } else if (e.getCurrentItem().getItemMeta().getDisplayName().equalsIgnoreCase("§cSpieler Verstecken")) {
/*  95 */       if (this.inHidePlayer.contains(p))
/*     */       {
/*  97 */         p.sendMessage(String.valueOf(String.valueOf(Data.CHAT_PREFIX)) + "§7Die Spieler werden bereits nicht mehr Angezeigt");
/*  98 */         p.playSound(p.getLocation(), Sound.ITEM_BREAK, 1.0F, 1.0F);
/*  99 */         p.closeInventory();
/*     */       }
/*     */       else
/*     */       {
/* 103 */         this.inHidePlayer.add(p);
/* 104 */         this.inShowPlayer.remove(p);
/* 105 */         hidePlayers(p);
/* 106 */         p.playSound(p.getLocation(), Sound.LEVEL_UP, 1.0F, 1.0F);
/* 107 */         p.addPotionEffect(new PotionEffect(PotionEffectType.BLINDNESS, 30, 999999));
/* 108 */         p.closeInventory();
/* 109 */         p.sendMessage(String.valueOf(String.valueOf(Data.CHAT_PREFIX)) + "§7Die Spieler werden nun nicht mehr Angezeigt");
/*     */       }
/*     */     
/* 112 */     } else if (e.getCurrentItem().getItemMeta().getDisplayName().equalsIgnoreCase("§5Nur Teamitglieder und YouTuber Anzeigen")) {
/* 113 */       if (this.inHidePlayer.contains(p)) {
/*     */         
/* 115 */         p.sendMessage(String.valueOf(String.valueOf(Data.CHAT_PREFIX)) + "§7Nur Teamitglieder und YouTuber werden bereits Angezeigt");
/* 116 */         p.playSound(p.getLocation(), Sound.ITEM_BREAK, 1.0F, 1.0F);
/* 117 */         p.closeInventory();
/*     */       }
/*     */       else {
/*     */         
/* 121 */         this.inHidePlayer.add(p);
/* 122 */         this.inShowPlayer.remove(p);
/* 123 */         showonlyVIPPlayers(p);
/* 124 */         p.playSound(p.getLocation(), Sound.LEVEL_UP, 1.0F, 1.0F);
/* 125 */         p.addPotionEffect(new PotionEffect(PotionEffectType.BLINDNESS, 30, 999999));
/* 126 */         p.closeInventory();
/* 127 */         p.sendMessage(String.valueOf(String.valueOf(Data.CHAT_PREFIX)) + "§7Nur noch Teamitglieder und YouTuber werden Angezeigt");
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public void hidePlayers(Player p) {
/* 133 */     for (Player all : Bukkit.getOnlinePlayers()) {
/* 134 */       p.hidePlayer(all);
/*     */     }
/*     */   }
/*     */   
/*     */   public void showPlayers(Player p) {
/* 139 */     for (Player all : Bukkit.getOnlinePlayers())
/* 140 */       p.showPlayer(all); 
/*     */   }
/*     */   
/*     */   public void showonlyVIPPlayers(Player p) {
/* 144 */     for (Player all : Bukkit.getOnlinePlayers()) {
/* 145 */       if (all.hasPermission("lobby.seeonlyvip")) {
/* 146 */         p.showPlayer(all); continue;
/*     */       } 
/* 148 */       p.hidePlayer(all);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\maxim\Desktop\Lobby.jar!\Listener\HideListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */