/*    */ package Methods;
/*    */ 
/*    */ import org.bukkit.Color;
/*    */ import org.bukkit.Material;
/*    */ import org.bukkit.inventory.ItemStack;
/*    */ import org.bukkit.inventory.meta.ItemMeta;
/*    */ import org.bukkit.inventory.meta.LeatherArmorMeta;
/*    */ 
/*    */ 
/*    */ public class Settings
/*    */ {
/*    */   public static ItemStack CreateItemwithID(Material mat, int subid, int amount, String DisplayName) {
/* 13 */     ItemStack is = new ItemStack(mat, amount, (short)subid);
/* 14 */     ItemMeta im = is.getItemMeta();
/* 15 */     im.setDisplayName(DisplayName);
/* 16 */     is.setItemMeta(im);
/* 17 */     return is;
/*    */   }
/*    */   
/*    */   public static ItemStack CreateBoot(Material mat, String DisplayName, Color color) {
/* 21 */     ItemStack is = new ItemStack(mat);
/* 22 */     LeatherArmorMeta im = (LeatherArmorMeta)is.getItemMeta();
/* 23 */     im.setDisplayName(DisplayName);
/* 24 */     im.setColor(color);
/* 25 */     is.setItemMeta((ItemMeta)im);
/* 26 */     return is;
/*    */   }
/*    */   
/*    */   public static ItemStack CreateHelmet(Material mat, String DisplayName, Color color) {
/* 30 */     ItemStack is = new ItemStack(mat);
/* 31 */     LeatherArmorMeta im = (LeatherArmorMeta)is.getItemMeta();
/* 32 */     im.setDisplayName(DisplayName);
/* 33 */     im.setColor(color);
/* 34 */     is.setItemMeta((ItemMeta)im);
/* 35 */     return is;
/*    */   }
/*    */   
/*    */   public static ItemStack CreateLeggings(Material mat, String DisplayName, Color color) {
/* 39 */     ItemStack is = new ItemStack(mat);
/* 40 */     LeatherArmorMeta im = (LeatherArmorMeta)is.getItemMeta();
/* 41 */     im.setDisplayName(DisplayName);
/* 42 */     im.setColor(color);
/* 43 */     is.setItemMeta((ItemMeta)im);
/* 44 */     return is;
/*    */   }
/*    */   
/*    */   public static ItemStack CreateChestplate(Material mat, String DisplayName, Color color) {
/* 48 */     ItemStack is = new ItemStack(mat);
/* 49 */     LeatherArmorMeta im = (LeatherArmorMeta)is.getItemMeta();
/* 50 */     im.setDisplayName(DisplayName);
/* 51 */     im.setColor(color);
/* 52 */     is.setItemMeta((ItemMeta)im);
/* 53 */     return is;
/*    */   }
/*    */   public static ItemStack CreateItemwithID(Material monsterEgg, int i, int j, String string, String string2) {
/* 56 */     return null;
/*    */   }
/*    */   public static ItemStack CreateItemwithID(Material diamondBoots, String string) {
/* 59 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\maxim\Desktop\Lobby.jar!\Methods\Settings.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */