/*    */ package Methods;
/*    */ 
/*    */ import org.bukkit.Material;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.inventory.ItemStack;
/*    */ import org.bukkit.inventory.meta.ItemMeta;
/*    */ 
/*    */ 
/*    */ public class Items
/*    */ {
/*    */   public static void giveItems(Player p) {
/* 12 */     p.getInventory().setItem(0, Settings.CreateItemwithID(Material.COMPASS, 0, 1, "§eNavigator §8× §7Rechtsklick"));
/* 13 */     p.getInventory().setItem(1, Settings.CreateItemwithID(Material.BLAZE_ROD, 0, 1, "§9Spieler-Verstecken §8× §7Rechtsklick"));
/* 14 */     p.getInventory().setItem(8, Settings.CreateItemwithID(Material.ENDER_CHEST, 0, 1, "§3Extras §8× §7Rechtsklick"));
/*    */     
/* 16 */     ItemStack is = new ItemStack(Material.FISHING_ROD);
/* 17 */     ItemMeta im = is.getItemMeta();
/* 18 */     im.setDisplayName("§6Enterhaken §8× §7Rechtsklick");
/* 19 */     im.spigot().setUnbreakable(true);
/* 20 */     is.setItemMeta(im);
/* 21 */     p.getInventory().setItem(7, is);
/*    */     
/* 23 */     if (p.hasPermission("lobby.vip")) {
/* 24 */       p.getInventory().setItem(0, Settings.CreateItemwithID(Material.COMPASS, 0, 1, "§eNavigator §8× §7Rechtsklick"));
/* 25 */       p.getInventory().setItem(1, Settings.CreateItemwithID(Material.BLAZE_ROD, 0, 1, "§9Spieler-Verstecken §8× §7Rechtsklick"));
/* 26 */       p.getInventory().setItem(8, Settings.CreateItemwithID(Material.ENDER_CHEST, 0, 1, "§3Extras §8× §7Rechtsklick"));
/* 27 */       p.getInventory().setItem(4, Settings.CreateItemwithID(Material.EYE_OF_ENDER, 0, 1, "§5Schutzschild §8┃ §cAus §8× §7Rechtsklick"));
/*    */       
/* 29 */       ItemStack is1 = new ItemStack(Material.FISHING_ROD);
/* 30 */       ItemMeta im1 = is.getItemMeta();
/* 31 */       im1.setDisplayName("§6Enterhaken §8× §7Rechtsklick");
/* 32 */       im1.spigot().setUnbreakable(true);
/* 33 */       is1.setItemMeta(im1);
/* 34 */       p.getInventory().setItem(7, is1);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\maxim\Desktop\Lobby.jar!\Methods\Items.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */