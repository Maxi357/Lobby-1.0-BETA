/*    */ package Methods;
/*    */ 
/*    */ import org.bukkit.Material;
/*    */ import org.bukkit.inventory.ItemStack;
/*    */ 
/*    */ public class ItemUtils
/*    */ {
/*    */   public static ItemStack getItem(Material stainedGlassPane, String string, String string2, int i, int j) {
/*  9 */     return null;
/*    */   }
/*    */   
/*    */   public static ItemStack createItem(Material diamondBoots, int i, int j, String string) {
/* 13 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\maxim\Desktop\Lobby.jar!\Methods\ItemUtils.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */