/*    */ package Special;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import org.bukkit.Color;
/*    */ import org.bukkit.Material;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.EventHandler;
/*    */ import org.bukkit.event.Listener;
/*    */ import org.bukkit.event.player.PlayerPickupItemEvent;
/*    */ import org.bukkit.inventory.ItemStack;
/*    */ import org.bukkit.inventory.meta.ItemMeta;
/*    */ import org.bukkit.inventory.meta.LeatherArmorMeta;
/*    */ 
/*    */ public class Boots implements Listener {
/* 15 */   public static ArrayList<Player> list = new ArrayList<>();
/* 16 */   public static ArrayList<Player> list1 = new ArrayList<>();
/* 17 */   public static ArrayList<Player> list2 = new ArrayList<>();
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @EventHandler
/*    */   public void onP(PlayerPickupItemEvent e) {
/* 24 */     if (e.getItem().getItemStack().getType() == Material.COOKIE || e.getItem().getItemStack().getType() == Material.DIAMOND)
/* 25 */       e.setCancelled(true); 
/*    */   }
/*    */   
/*    */   public static void addKekse(Player p) {
/* 29 */     list.add(p);
/* 30 */     ItemStack i = new ItemStack(Material.LEATHER_BOOTS);
/* 31 */     LeatherArmorMeta im = (LeatherArmorMeta)i.getItemMeta();
/* 32 */     im.setColor(Color.ORANGE);
/* 33 */     i.setItemMeta((ItemMeta)im);
/*    */     
/* 35 */     p.getInventory().setBoots(i);
/*    */   }
/*    */   public static void removeKekse(Player p) {
/* 38 */     list.remove(p);
/* 39 */     p.getInventory().setBoots(null);
/*    */   }
/*    */   public static void addDiamonds(Player p) {
/* 42 */     list1.add(p);
/* 43 */     ItemStack i = new ItemStack(Material.LEATHER_BOOTS);
/* 44 */     LeatherArmorMeta im = (LeatherArmorMeta)i.getItemMeta();
/* 45 */     im.setColor(Color.AQUA);
/* 46 */     i.setItemMeta((ItemMeta)im);
/*    */     
/* 48 */     p.getInventory().setBoots(i);
/*    */   }
/*    */   public static void removeDiamonds(Player p) {
/* 51 */     list1.remove(p);
/* 52 */     p.getInventory().setBoots(null);
/*    */   }
/*    */   public static void addGold(Player p) {
/* 55 */     list2.add(p);
/* 56 */     ItemStack i = new ItemStack(Material.LEATHER_BOOTS);
/* 57 */     LeatherArmorMeta im = (LeatherArmorMeta)i.getItemMeta();
/* 58 */     im.setColor(Color.YELLOW);
/* 59 */     i.setItemMeta((ItemMeta)im);
/*    */     
/* 61 */     p.getInventory().setBoots(i);
/*    */   }
/*    */   public static void removeGold(Player p) {
/* 64 */     list2.remove(p);
/* 65 */     p.getInventory().setBoots(null);
/*    */   }
/*    */ }


/* Location:              C:\Users\maxim\Desktop\Lobby.jar!\Special\Boots.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */