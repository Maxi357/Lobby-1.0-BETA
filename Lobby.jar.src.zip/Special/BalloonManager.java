/*    */ package Special;
/*    */ 
/*    */ import org.bukkit.Location;
/*    */ import org.bukkit.Material;
/*    */ import org.bukkit.entity.Entity;
/*    */ import org.bukkit.entity.EntityType;
/*    */ import org.bukkit.entity.FallingBlock;
/*    */ import org.bukkit.entity.LivingEntity;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.potion.PotionEffect;
/*    */ import org.bukkit.potion.PotionEffectType;
/*    */ 
/*    */ public class BalloonManager
/*    */ {
/*    */   private Player player;
/*    */   private LivingEntity bat;
/*    */   private FallingBlock block;
/*    */   
/*    */   public BalloonManager(Player player, LivingEntity bat, FallingBlock block) {
/* 20 */     this.player = player;
/* 21 */     this.bat = bat;
/* 22 */     this.block = block;
/*    */   }
/*    */ 
/*    */   
/*    */   public Player getPlayer() {
/* 27 */     return this.player;
/*    */   }
/*    */ 
/*    */   
/*    */   public LivingEntity getBat() {
/* 32 */     return this.bat;
/*    */   }
/*    */ 
/*    */   
/*    */   public FallingBlock getBlock() {
/* 37 */     return this.block;
/*    */   }
/*    */ 
/*    */   
/*    */   public static BalloonManager spawnNewInstance(Player player, byte data) {
/* 42 */     Location location = player.getEyeLocation().add(1.0D, 3.0D, 1.0D);
/* 43 */     LivingEntity bat = (LivingEntity)player.getWorld().spawnEntity(location, EntityType.BAT);
/*    */     
/* 45 */     FallingBlock fallingBlock = player.getWorld().spawnFallingBlock(location, Material.STAINED_CLAY, data);
/* 46 */     fallingBlock.setDropItem(false);
/* 47 */     bat.setPassenger((Entity)fallingBlock);
/* 48 */     bat.setLeashHolder((Entity)player);
/* 49 */     bat.setRemoveWhenFarAway(false);
/* 50 */     bat.addPotionEffect(new PotionEffect(PotionEffectType.INVISIBILITY, 100000, 100000));
/* 51 */     BalloonManager balloon = new BalloonManager(player, bat, fallingBlock);
/* 52 */     return balloon;
/*    */   }
/*    */ }


/* Location:              C:\Users\maxim\Desktop\Lobby.jar!\Special\BalloonManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */