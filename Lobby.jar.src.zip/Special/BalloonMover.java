/*    */ package Special;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ import org.bukkit.Material;
/*    */ import org.bukkit.entity.FallingBlock;
/*    */ import org.bukkit.entity.LivingEntity;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.inventory.ItemStack;
/*    */ 
/*    */ 
/*    */ public class BalloonMover
/*    */ {
/*    */   public static BalloonMover instance;
/* 14 */   public HashMap<Player, BalloonManager> balloons = new HashMap<>();
/*    */ 
/*    */   
/*    */   public BalloonMover() {
/* 18 */     instance = this;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void resetBalloon(Player p) {
/* 24 */     if (hasBalloon(p)) {
/* 25 */       takeBalloon(p);
/*    */     }
/* 27 */     ItemStack is = p.getItemInHand();
/* 28 */     if (is != null) {
/*    */       
/* 30 */       if (is.getType().equals(Material.STAINED_CLAY)) {
/* 31 */         giveBalloon(p, is.getData().getData());
/* 32 */       } else if (hasBalloon(p)) {
/* 33 */         takeBalloon(p);
/*    */       }
/*    */     
/* 36 */     } else if (hasBalloon(p)) {
/* 37 */       takeBalloon(p);
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void resetBalloon(Player p, ItemStack is) {
/* 44 */     if (hasBalloon(p)) {
/* 45 */       takeBalloon(p);
/*    */     }
/* 47 */     if (is != null) {
/*    */       
/* 49 */       if (is.getType().equals(Material.STAINED_CLAY)) {
/* 50 */         giveBalloon(p, is.getData().getData());
/* 51 */       } else if (hasBalloon(p)) {
/* 52 */         takeBalloon(p);
/*    */       }
/*    */     
/* 55 */     } else if (hasBalloon(p)) {
/* 56 */       takeBalloon(p);
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public void giveBalloon(Player p, byte data) {
/* 62 */     BalloonManager balloon = BalloonManager.spawnNewInstance(p, data);
/* 63 */     this.balloons.put(p, balloon);
/*    */   }
/*    */ 
/*    */   
/*    */   public void takeBalloon(Player p) {
/* 68 */     if (hasBalloon(p)) {
/*    */       
/* 70 */       BalloonManager balloon = this.balloons.get(p);
/* 71 */       FallingBlock block = balloon.getBlock();
/* 72 */       if (block != null) {
/* 73 */         block.remove();
/*    */       }
/* 75 */       LivingEntity bat = balloon.getBat();
/* 76 */       if (bat != null) {
/* 77 */         bat.remove();
/*    */       }
/* 79 */       this.balloons.put(p, null);
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean hasBalloon(Player p) {
/* 85 */     return (this.balloons.get(p) != null);
/*    */   }
/*    */ }


/* Location:              C:\Users\maxim\Desktop\Lobby.jar!\Special\BalloonMover.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */