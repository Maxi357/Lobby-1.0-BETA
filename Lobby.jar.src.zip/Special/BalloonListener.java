/*    */ package Special;
/*    */ 
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.EventHandler;
/*    */ import org.bukkit.event.Listener;
/*    */ import org.bukkit.event.entity.EntityChangeBlockEvent;
/*    */ import org.bukkit.event.entity.EntityDamageByBlockEvent;
/*    */ import org.bukkit.event.entity.EntityDamageByEntityEvent;
/*    */ import org.bukkit.event.entity.EntityDamageEvent;
/*    */ import org.bukkit.event.player.PlayerJoinEvent;
/*    */ import org.bukkit.event.player.PlayerQuitEvent;
/*    */ 
/*    */ 
/*    */ public class BalloonListener
/*    */   implements Listener
/*    */ {
/*    */   @EventHandler
/*    */   public void onPlayerJoin(PlayerJoinEvent e) {
/* 19 */     Player p = e.getPlayer();
/* 20 */     BalloonMover.instance.resetBalloon(p);
/*    */   }
/*    */ 
/*    */   
/*    */   @EventHandler
/*    */   public void onPlayerQuit(PlayerQuitEvent e) {
/* 26 */     Player p = e.getPlayer();
/* 27 */     if (BalloonMover.instance.hasBalloon(p)) {
/* 28 */       BalloonMover.instance.takeBalloon(p);
/*    */     }
/*    */   }
/*    */ 
/*    */   
/*    */   @EventHandler
/*    */   public void onEntityChangeBlockEvent(EntityChangeBlockEvent e) {
/* 35 */     e.setCancelled(true);
/*    */   }
/*    */ 
/*    */   
/*    */   @EventHandler
/*    */   public void onEntityDamage(EntityDamageEvent e) {
/* 41 */     if (e.getEntity() instanceof org.bukkit.entity.Bat) {
/* 42 */       e.setCancelled(true);
/*    */     }
/*    */   }
/*    */ 
/*    */   
/*    */   @EventHandler
/*    */   public void onEntityDamage(EntityDamageByBlockEvent e) {
/* 49 */     if (e.getEntity() instanceof org.bukkit.entity.Bat) {
/* 50 */       e.setCancelled(true);
/*    */     }
/*    */   }
/*    */ 
/*    */   
/*    */   @EventHandler
/*    */   public void onEntityDamage(EntityDamageByEntityEvent e) {
/* 57 */     if (e.getEntity() instanceof org.bukkit.entity.Bat)
/* 58 */       e.setCancelled(true); 
/*    */   }
/*    */ }


/* Location:              C:\Users\maxim\Desktop\Lobby.jar!\Special\BalloonListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */