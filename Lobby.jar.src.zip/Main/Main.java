/*     */ package Main;
/*     */ 
/*     */ import Commands.BuildCommand;
/*     */ import Commands.FlyCommand;
/*     */ import Commands.GMCommand;
/*     */ import Commands.GameModeCommand;
/*     */ import Commands.SetSpawnCommand;
/*     */ import Listener.BuildListener;
/*     */ import Listener.ChatListener;
/*     */ import Listener.DamageListener;
/*     */ import Listener.DropListener;
/*     */ import Listener.EnterhakenListener;
/*     */ import Listener.ExtrasListener;
/*     */ import Listener.Extras_ItemsListener;
/*     */ import Listener.FoodLevelChangeListener;
/*     */ import Listener.HideListener;
/*     */ import Listener.InventoryMoveListener;
/*     */ import Listener.JoinListener;
/*     */ import Listener.PickupItemListener;
/*     */ import Listener.QuitListener;
/*     */ import Listener.ReloadListener;
/*     */ import Listener.SchutzSchildListener;
/*     */ import Listener.StopListener;
/*     */ import Listener.TeleportListener;
/*     */ import Listener.UnknownListener;
/*     */ import Special.BalloonMover;
/*     */ import Special.Boots;
/*     */ import java.util.ArrayList;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.Difficulty;
/*     */ import org.bukkit.Location;
/*     */ import org.bukkit.Material;
/*     */ import org.bukkit.World;
/*     */ import org.bukkit.command.CommandExecutor;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.event.Listener;
/*     */ import org.bukkit.inventory.ItemStack;
/*     */ import org.bukkit.plugin.Plugin;
/*     */ import org.bukkit.plugin.java.JavaPlugin;
/*     */ 
/*     */ 
/*     */ public class Main
/*     */   extends JavaPlugin
/*     */ {
/*  45 */   public ArrayList<Player> buildmode = new ArrayList<>();
/*  46 */   public ArrayList<Player> flymode = new ArrayList<>();
/*     */   
/*     */   public static Main plugin;
/*     */   
/*     */   public void onEnable() {
/*  51 */     Bukkit.getConsoleSender().sendMessage("§8=====[§aLobbySystem§8]=====");
/*  52 */     Bukkit.getConsoleSender().sendMessage("§7Das Plugin wurde §ageladen");
/*  53 */     Bukkit.getConsoleSender().sendMessage("§7Die Listener wurden §ageladen");
/*  54 */     Bukkit.getConsoleSender().sendMessage("§7Die Commands wurden §ageladen");
/*  55 */     Bukkit.getConsoleSender().sendMessage("");
/*  56 */     Bukkit.getConsoleSender().sendMessage("§a§lDAS PLUGIN WURDE FERTIG §a§lGELADEN");
/*  57 */     Bukkit.getConsoleSender().sendMessage("§8=====[§aLobbySystem§8]=====");
/*  58 */     registerListener();
/*  59 */     registerCommands();
/*  60 */     plugin = this;
/*     */     
/*  62 */     for (World w : Bukkit.getWorlds()) {
/*  63 */       w.setGameRuleValue("doDaylightCycle", "false");
/*  64 */       w.setTime(0L);
/*  65 */       w.setDifficulty(Difficulty.PEACEFUL);
/*  66 */       w.setStorm(false);
/*  67 */       w.setGameRuleValue("keepInventory", "true");
/*     */     } 
/*     */     
/*  70 */     Bukkit.getScheduler().scheduleSyncRepeatingTask((Plugin)this, new Runnable()
/*     */         {
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           public void run() {}
/*     */         }, 
/*     */ 
/*     */ 
/*     */         
/*  81 */         20L, 100L);
/*  82 */     Bukkit.getScheduler().scheduleSyncRepeatingTask((Plugin)this, new Runnable() {
/*  83 */           ItemStack i = new ItemStack(Material.COOKIE, 1);
/*     */           
/*     */           public void run() {
/*  86 */             for (Player all : Bukkit.getOnlinePlayers()) {
/*  87 */               if (Boots.list.contains(all)) {
/*  88 */                 all.getWorld().dropItem(all.getLocation(), this.i);
/*     */               }
/*     */             } 
/*     */           }
/*  92 */         }20L, 2L);
/*  93 */     Bukkit.getScheduler().scheduleSyncRepeatingTask((Plugin)this, new Runnable()
/*     */         {
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           public void run() {}
/*     */         }, 
/*     */ 
/*     */ 
/*     */         
/* 104 */         20L, 100L);
/* 105 */     Bukkit.getScheduler().scheduleSyncRepeatingTask((Plugin)this, new Runnable() {
/* 106 */           ItemStack i = new ItemStack(Material.DIAMOND, 1);
/* 107 */           ItemStack i1 = new ItemStack(Material.DIAMOND_BLOCK, 1);
/*     */           
/*     */           public void run() {
/* 110 */             for (Player all : Bukkit.getOnlinePlayers()) {
/* 111 */               if (Boots.list1.contains(all)) {
/* 112 */                 all.getWorld().dropItem(all.getLocation(), this.i);
/* 113 */                 all.getWorld().dropItem(all.getLocation(), this.i1);
/*     */               } 
/*     */             } 
/*     */           }
/* 117 */         }20L, 2L);
/* 118 */     Bukkit.getScheduler().scheduleSyncRepeatingTask((Plugin)this, new Runnable()
/*     */         {
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           public void run() {}
/*     */         }, 
/*     */ 
/*     */ 
/*     */         
/* 129 */         20L, 100L);
/* 130 */     Bukkit.getScheduler().scheduleSyncRepeatingTask((Plugin)this, new Runnable() {
/* 131 */           ItemStack i = new ItemStack(Material.GOLD_INGOT, 1);
/* 132 */           ItemStack i1 = new ItemStack(Material.GOLD_BLOCK, 1);
/* 133 */           ItemStack i2 = new ItemStack(Material.GOLD_NUGGET, 1);
/*     */           
/*     */           public void run() {
/* 136 */             for (Player all : Bukkit.getOnlinePlayers()) {
/* 137 */               if (Boots.list2.contains(all)) {
/* 138 */                 all.getWorld().dropItem(all.getLocation(), this.i);
/* 139 */                 all.getWorld().dropItem(all.getLocation(), this.i1);
/* 140 */                 all.getWorld().dropItem(all.getLocation(), this.i2);
/*     */               } 
/*     */             } 
/*     */           }
/* 144 */         }20L, 2L);
/*     */     
/* 146 */     BalloonMover mover = BalloonMover.instance;
/* 147 */     for (Player player : getServer().getOnlinePlayers());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void onDisable() {
/* 155 */     Bukkit.getConsoleSender().sendMessage("§8=====[§aLobbySystem§8]=====");
/* 156 */     Bukkit.getConsoleSender().sendMessage("§7Das Plugin wurde §cDeaktiviert");
/* 157 */     Bukkit.getConsoleSender().sendMessage("§7Die Listener wurden §cDeaktiviert");
/* 158 */     Bukkit.getConsoleSender().sendMessage("§7Die Commands wurden §cDeaktiviert");
/* 159 */     Bukkit.getConsoleSender().sendMessage("");
/* 160 */     Bukkit.getConsoleSender().sendMessage("§a§lDAS PLUGIN WURDE FERTIG §c§lDEAKTIVIERT");
/* 161 */     Bukkit.getConsoleSender().sendMessage("§8=====[§aLobbySystem§8]=====");
/*     */   }
/*     */   
/*     */   public void registerListener() {
/* 165 */     Bukkit.getPluginManager().registerEvents((Listener)new JoinListener(), (Plugin)this);
/* 166 */     Bukkit.getPluginManager().registerEvents((Listener)new QuitListener(), (Plugin)this);
/* 167 */     Bukkit.getPluginManager().registerEvents((Listener)new FoodLevelChangeListener(), (Plugin)this);
/* 168 */     Bukkit.getPluginManager().registerEvents((Listener)new PickupItemListener(this), (Plugin)this);
/* 169 */     Bukkit.getPluginManager().registerEvents((Listener)new InventoryMoveListener(this), (Plugin)this);
/* 170 */     Bukkit.getPluginManager().registerEvents((Listener)new DropListener(this), (Plugin)this);
/* 171 */     Bukkit.getPluginManager().registerEvents((Listener)new DamageListener(), (Plugin)this);
/* 172 */     Bukkit.getPluginManager().registerEvents((Listener)new ChatListener(), (Plugin)this);
/* 173 */     Bukkit.getPluginManager().registerEvents((Listener)new BuildListener(this), (Plugin)this);
/* 174 */     Bukkit.getPluginManager().registerEvents((Listener)new HideListener(), (Plugin)this);
/* 175 */     Bukkit.getPluginManager().registerEvents((Listener)new SchutzSchildListener(), (Plugin)this);
/* 176 */     Bukkit.getPluginManager().registerEvents((Listener)new EnterhakenListener(), (Plugin)this);
/* 177 */     Bukkit.getPluginManager().registerEvents((Listener)new Boots(), (Plugin)this);
/* 178 */     Bukkit.getPluginManager().registerEvents((Listener)new ExtrasListener(), (Plugin)this);
/* 179 */     Bukkit.getPluginManager().registerEvents((Listener)new Extras_ItemsListener(), (Plugin)this);
/* 180 */     Bukkit.getPluginManager().registerEvents((Listener)new TeleportListener(this), (Plugin)this);
/* 181 */     Bukkit.getPluginManager().registerEvents((Listener)new ReloadListener(), (Plugin)this);
/* 182 */     Bukkit.getPluginManager().registerEvents((Listener)new StopListener(), (Plugin)this);
/* 183 */     Bukkit.getPluginManager().registerEvents((Listener)new UnknownListener(), (Plugin)this);
/*     */   }
/*     */   
/*     */   public void registerCommands() {
/* 187 */     getCommand("build").setExecutor((CommandExecutor)new BuildCommand(this));
/* 188 */     getCommand("setwarp").setExecutor((CommandExecutor)new SetSpawnCommand(this));
/* 189 */     getCommand("fly").setExecutor((CommandExecutor)new FlyCommand(this));
/* 190 */     getCommand("gamemode").setExecutor((CommandExecutor)new GameModeCommand());
/* 191 */     getCommand("gm").setExecutor((CommandExecutor)new GMCommand());
/*     */   }
/*     */   
/*     */   public static Main getInstance() {
/* 195 */     return plugin;
/*     */   }
/*     */   public Location getspawn() {
/* 198 */     Location loc = null;
/* 199 */     String world = getConfig().getString("spawn.world");
/* 200 */     double x = getConfig().getDouble("spawn.x");
/* 201 */     double y = getConfig().getDouble("spawn.y");
/* 202 */     double z = getConfig().getDouble("spawn.z");
/* 203 */     float yaw = (float)getConfig().getDouble("spawn.yaw");
/* 204 */     float pitch = (float)getConfig().getDouble("spawn.pitch");
/* 205 */     loc = new Location(Bukkit.getWorld(world), x, y, z, yaw, pitch);
/* 206 */     return loc;
/*     */   }
/*     */   public Location getknockoutloc() {
/* 209 */     Location loc = null;
/* 210 */     String world = getConfig().getString("spawn.knockout.world");
/* 211 */     double x = getConfig().getDouble("spawn.knockout.x");
/* 212 */     double y = getConfig().getDouble("spawn.knockout.y");
/* 213 */     double z = getConfig().getDouble("spawn.knockout.z");
/* 214 */     float yaw = (float)getConfig().getDouble("spawn.knockout.yaw");
/* 215 */     float pitch = (float)getConfig().getDouble("spawn.knockout.pitch");
/* 216 */     loc = new Location(Bukkit.getWorld(world), x, y, z, yaw, pitch);
/* 217 */     return loc;
/*     */   }
/*     */   public Location getskywarsloc1() {
/* 220 */     Location loc = null;
/* 221 */     String world = getConfig().getString("spawn.SkyWars.world");
/* 222 */     double x = getConfig().getDouble("spawn.skywars.x");
/* 223 */     double y = getConfig().getDouble("spawn.skywars.y");
/* 224 */     double z = getConfig().getDouble("spawn.skywars.z");
/* 225 */     float yaw = (float)getConfig().getDouble("spawn.skywars.yaw");
/* 226 */     float pitch = (float)getConfig().getDouble("spawn.skywars.pitch");
/* 227 */     loc = new Location(Bukkit.getWorld(world), x, y, z, yaw, pitch);
/* 228 */     return loc;
/*     */   }
/*     */   public Location getskypvploc() {
/* 231 */     Location loc = null;
/* 232 */     String world = getConfig().getString("spawn.skypvp.world");
/* 233 */     double x = getConfig().getDouble("spawn.skypvp.x");
/* 234 */     double y = getConfig().getDouble("spawn.skypvp.y");
/* 235 */     double z = getConfig().getDouble("spawn.skypvp.z");
/* 236 */     float yaw = (float)getConfig().getDouble("spawn.skypvp.yaw");
/* 237 */     float pitch = (float)getConfig().getDouble("spawn.skypvp.pitch");
/* 238 */     loc = new Location(Bukkit.getWorld(world), x, y, z, yaw, pitch);
/* 239 */     return loc;
/*     */   }
/*     */   public Location getcomingsoonloc() {
/* 242 */     Location loc = null;
/* 243 */     String world = getConfig().getString("spawn.comingsoon.world");
/* 244 */     double x = getConfig().getDouble("spawn.comingsoon.x");
/* 245 */     double y = getConfig().getDouble("spawn.comingsoon.y");
/* 246 */     double z = getConfig().getDouble("spawn.comingsoon.z");
/* 247 */     float yaw = (float)getConfig().getDouble("spawn.comingsoon.yaw");
/* 248 */     float pitch = (float)getConfig().getDouble("spawn.comingsoon.pitch");
/* 249 */     loc = new Location(Bukkit.getWorld(world), x, y, z, yaw, pitch);
/* 250 */     return loc;
/*     */   }
/*     */   public Location getcommunityloc() {
/* 253 */     Location loc = null;
/* 254 */     String world = getConfig().getString("spawn.community.world");
/* 255 */     double x = getConfig().getDouble("spawn.community.x");
/* 256 */     double y = getConfig().getDouble("spawn.community.y");
/* 257 */     double z = getConfig().getDouble("spawn.community.z");
/* 258 */     float yaw = (float)getConfig().getDouble("spawn.community.yaw");
/* 259 */     float pitch = (float)getConfig().getDouble("spawn.community.pitch");
/* 260 */     loc = new Location(Bukkit.getWorld(world), x, y, z, yaw, pitch);
/* 261 */     return loc;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Location getskywarsloc() {
/* 268 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\maxim\Desktop\Lobby.jar!\Main\Main.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */