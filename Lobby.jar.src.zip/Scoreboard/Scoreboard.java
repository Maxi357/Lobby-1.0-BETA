/*     */ package Scoreboard;
/*     */ 
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.scoreboard.DisplaySlot;
/*     */ import org.bukkit.scoreboard.Objective;
/*     */ import org.bukkit.scoreboard.Team;
/*     */ import ru.tehkode.permissions.bukkit.PermissionsEx;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Scoreboard
/*     */ {
/*     */   public static Team getTeamForPlayer(org.bukkit.scoreboard.Scoreboard board, Player forWhom) {
/*  16 */     if (PermissionsEx.getUser(forWhom).inGroup("Owner")) {
/*  17 */       return board.getTeam("a");
/*     */     }
/*  19 */     if (PermissionsEx.getUser(forWhom).inGroup("Admin")) {
/*  20 */       return board.getTeam("b");
/*     */     }
/*  22 */     if (PermissionsEx.getUser(forWhom).inGroup("SrDeveloper")) {
/*  23 */       return board.getTeam("c");
/*     */     }
/*  25 */     if (PermissionsEx.getUser(forWhom).inGroup("SrModerator")) {
/*  26 */       return board.getTeam("d");
/*     */     }
/*  28 */     if (PermissionsEx.getUser(forWhom).inGroup("SrBuilder")) {
/*  29 */       return board.getTeam("e");
/*     */     }
/*  31 */     if (PermissionsEx.getUser(forWhom).inGroup("Developer")) {
/*  32 */       return board.getTeam("f");
/*     */     }
/*  34 */     if (PermissionsEx.getUser(forWhom).inGroup("Moderator")) {
/*  35 */       return board.getTeam("g");
/*     */     }
/*  37 */     if (PermissionsEx.getUser(forWhom).inGroup("Supporter")) {
/*  38 */       return board.getTeam("h");
/*     */     }
/*  40 */     if (PermissionsEx.getUser(forWhom).inGroup("Builder")) {
/*  41 */       return board.getTeam("i");
/*     */     }
/*  43 */     if (PermissionsEx.getUser(forWhom).inGroup("YouTuber")) {
/*  44 */       return board.getTeam("j");
/*     */     }
/*  46 */     if (PermissionsEx.getUser(forWhom).inGroup("Premium+")) {
/*  47 */       return board.getTeam("k");
/*     */     }
/*  49 */     if (PermissionsEx.getUser(forWhom).inGroup("Premium")) {
/*  50 */       return board.getTeam("l");
/*     */     }
/*  52 */     return board.getTeam("z");
/*     */   }
/*     */   
/*     */   public static Team searchTeamsForEntry(Player forWhom, String entry) {
/*  56 */     if (forWhom.getScoreboard() == null) {
/*  57 */       setScoreboard(forWhom);
/*     */     }
/*  59 */     org.bukkit.scoreboard.Scoreboard board = forWhom.getScoreboard();
/*  60 */     for (Team team : board.getTeams()) {
/*  61 */       if (!team.hasEntry(entry))
/*  62 */         continue;  return team;
/*     */     } 
/*  64 */     return null;
/*     */   }
/*     */   
/*     */   public static void setScoreboard(Player p) {
/*  68 */     org.bukkit.scoreboard.Scoreboard board2 = Bukkit.getScoreboardManager().getNewScoreboard();
/*  69 */     Team Owner = board2.registerNewTeam("a");
/*  70 */     Team Admin = board2.registerNewTeam("b");
/*  71 */     Team SrDeveloper = board2.registerNewTeam("c");
/*  72 */     Team SrModerator = board2.registerNewTeam("d");
/*  73 */     Team SrBuilder = board2.registerNewTeam("e");
/*  74 */     Team Developer = board2.registerNewTeam("f");
/*  75 */     Team Moderator = board2.registerNewTeam("g");
/*  76 */     Team Supporter = board2.registerNewTeam("h");
/*  77 */     Team Builder = board2.registerNewTeam("i");
/*  78 */     Team YouTuber = board2.registerNewTeam("j");
/*  79 */     Team PremiumPlus = board2.registerNewTeam("k");
/*  80 */     Team Premium = board2.registerNewTeam("l");
/*  81 */     Team Spieler = board2.registerNewTeam("z");
/*  82 */     Owner.setPrefix("§4Owner §8● §4");
/*  83 */     Admin.setPrefix("§4Admin §8● §4");
/*  84 */     SrDeveloper.setPrefix("§bSrDev §8● §b");
/*  85 */     SrModerator.setPrefix("§9SrMod §8● §9");
/*  86 */     SrBuilder.setPrefix("§2SrBuild §8● §2");
/*  87 */     Developer.setPrefix("§bDev §8● §b");
/*  88 */     Moderator.setPrefix("§9Mod §8● §9");
/*  89 */     Supporter.setPrefix("§3Support §8● §3");
/*  90 */     Builder.setPrefix("§2Build §8● §2");
/*  91 */     YouTuber.setPrefix("§5YouTube §8● §5");
/*  92 */     PremiumPlus.setPrefix("§ePrem+ §8● §e");
/*  93 */     Premium.setPrefix("§6Prem §8● §6");
/*  94 */     Spieler.setPrefix("§7");
/*  95 */     for (Player all : Bukkit.getOnlinePlayers()) {
/*  96 */       Team playerTeam = getTeamForPlayer(board2, all);
/*  97 */       if (playerTeam.hasEntry(all.getName()))
/*  98 */         continue;  playerTeam.addEntry(all.getName());
/*     */     } 
/* 100 */     Objective ob = board2.registerNewObjective("Lobby", "System");
/* 101 */     ob.setDisplaySlot(DisplaySlot.SIDEBAR);
/* 102 */     ob.setDisplayName("§8● §6Lobby §8●");
/* 103 */     ob.getScore("§a").setScore(12);
/* 104 */     ob.getScore("§8┃ §7Dein Rang§8:").setScore(11);
/* 105 */     if (PermissionsEx.getUser(p).inGroup("Owner")) {
/* 106 */       ob.getScore("§8● §4Owner").setScore(10);
/* 107 */     } else if (PermissionsEx.getUser(p).inGroup("Admin")) {
/* 108 */       ob.getScore("§8● §4Admin").setScore(10);
/* 109 */     } else if (PermissionsEx.getUser(p).inGroup("SrDeveloper")) {
/* 110 */       ob.getScore("§8● §bSrDeveloper").setScore(10);
/* 111 */     } else if (PermissionsEx.getUser(p).inGroup("SrModerator")) {
/* 112 */       ob.getScore("§8● §9SrModerator").setScore(10);
/* 113 */     } else if (PermissionsEx.getUser(p).inGroup("SrBuilder")) {
/* 114 */       ob.getScore("§8● §2SrBuilder").setScore(10);
/* 115 */     } else if (PermissionsEx.getUser(p).inGroup("Developer")) {
/* 116 */       ob.getScore("§8● §bDeveloper").setScore(10);
/* 117 */     } else if (PermissionsEx.getUser(p).inGroup("Moderator")) {
/* 118 */       ob.getScore("§8● §9Moderator").setScore(10);
/* 119 */     } else if (PermissionsEx.getUser(p).inGroup("Supporter")) {
/* 120 */       ob.getScore("§8● §3Supporter").setScore(10);
/* 121 */     } else if (PermissionsEx.getUser(p).inGroup("Builder")) {
/* 122 */       ob.getScore("§8● §2Builder").setScore(10);
/* 123 */     } else if (PermissionsEx.getUser(p).inGroup("YouTuber")) {
/* 124 */       ob.getScore("§8● §5YouTuber").setScore(10);
/* 125 */     } else if (PermissionsEx.getUser(p).inGroup("Premium+")) {
/* 126 */       ob.getScore("§8● §ePremium+").setScore(10);
/* 127 */     } else if (PermissionsEx.getUser(p).inGroup("Premium")) {
/* 128 */       ob.getScore("§8● §6Premium").setScore(10);
/* 129 */     } else if (PermissionsEx.getUser(p).inGroup("Spieler")) {
/* 130 */       ob.getScore("§8● §7Spieler").setScore(10);
/* 131 */     }  ob.getScore("§b").setScore(9);
/* 132 */     ob.getScore("§8┃ §7Teamspeak³§8:").setScore(8);
/* 133 */     ob.getScore("§8● §eRaparaxMC§7.§enet").setScore(7);
/* 134 */     ob.getScore("§c").setScore(6);
/* 135 */     ob.getScore("§8┃ §7Forum§8:").setScore(5);
/* 136 */     ob.getScore("§8§8● §cIn Arbeit").setScore(4);
/* 137 */     ob.getScore("§d").setScore(3);
/* 138 */     ob.getScore("§8┃ §7Server§8:").setScore(2);
/* 139 */     ob.getScore("§8§8§8● §e§e§eLobby-1").setScore(1);
/*     */     
/* 141 */     p.setScoreboard(board2);
/*     */   }
/*     */ }


/* Location:              C:\Users\maxim\Desktop\Lobby.jar!\Scoreboard\Scoreboard.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */